#!/bin/bash

# ****** use this script to run under Linux or on a Chromebook under the Linux sub system *****
#
# Define the absolute path to the script's directory for robust execution
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# --- Configuration (using absolute paths where possible) ---
VENV_PATH="$SCRIPT_DIR/.venv_pcmanager"
PYTHON_BIN="python3"
SCRIPT_NAME="manager.py"
REQUIREMENTS_FILE="$SCRIPT_DIR/requirements.txt"

clear
echo "--- Remote Linux Manager Startup ---"

# --- 1. System Dependency Check and Installation ---
echo "[INFO] Checking for essential system dependencies (Python, venv, GTK bindings)..."

# Check if apt-get is available for installation
if ! command -v apt-get &> /dev/null; then
    echo ""
    echo "[FATAL] The 'apt-get' command was not found."
    echo "This script is designed for Debian/Ubuntu systems."
    echo "Please install Python 3 and PyGObject manually for your distribution."
    exit 1
fi

# Define required system packages for running the Python GUI and venv
declare -a REQUIRED_PACKAGES=("python3" "python3-venv" "python3-gi" "python3-tk")
declare -a MISSING_PACKAGES=()

# Check for missing packages using dpkg-query
for PKG in "${REQUIRED_PACKAGES[@]}"; do
    if ! dpkg-query -W -f='${Status}' "$PKG" 2>/dev/null | grep -q "install ok installed"; then
        MISSING_PACKAGES+=("$PKG")
    fi
done

if [ ${#MISSING_PACKAGES[@]} -gt 0 ]; then
    echo ""
    echo "=================================================================="
    echo "  [ACTION REQUIRED] Missing Critical System Packages Detected!"
    echo "  The following packages are required to run the GUI:"
    echo "  -> ${MISSING_PACKAGES[@]}"
    echo "=================================================================="
    echo "The script will now attempt to install these using 'sudo apt-get install'."
    echo "You may be prompted for your sudo password."

    # Installation
    sudo apt-get update
    if sudo apt-get install -y "${MISSING_PACKAGES[@]}"; then
        echo "[SUCCESS] Required system packages installed."
    else
        echo "[FATAL] Failed to install required system packages."
        echo "Please check the error above and resolve installation issues."
        exit 1
    fi
fi
# --- End Dependency Check and Installation ---

# 2. Check for basic Python availability (Final check after installation attempt)
if ! command -v $PYTHON_BIN &> /dev/null
then
    echo "[FATAL] Python 3 is still not installed or not in PATH. Cannot continue."
    exit 1
fi

# 3. Virtual Environment Setup
if [ ! -d "$VENV_PATH" ]; then
    echo "[INFO] Setting up new virtual environment (inheriting system packages)..."
    # Use --system-site-packages to include system-installed GI/GTK bindings
    $PYTHON_BIN -m venv --system-site-packages "$VENV_PATH"
fi

# 4. Define Venv Binaries Explicitly
VENV_PYTHON="$VENV_PATH/bin/python"
VENV_PIP="$VENV_PATH/bin/pip"

# 5. Guaranteed requirements.txt creation (Ensures the file exists)
if [ ! -f "$REQUIREMENTS_FILE" ]; then
    echo "[INFO] Creating missing $REQUIREMENTS_FILE..."
    cat <<EOF > "$REQUIREMENTS_FILE"
paramiko
cryptography
EOF
fi

# 6. Install Python Dependencies inside venv (CRITICAL FIX: --break-system-packages)
echo "[INFO] Checking Python package dependencies inside venv..."

# Use the --break-system-packages flag for modern Python installs.
$VENV_PIP install -r "$REQUIREMENTS_FILE" --disable-pip-version-check --break-system-packages
INSTALL_STATUS=$?

if [ $INSTALL_STATUS -ne 0 ]; then
    echo "[ERROR] Failed to install Python dependencies. Please check network connection and PyPi status."
    exit 1
fi

# 7. Launch Application and wait for it to finish gracefully.
echo "[INFO] All dependencies met. Launching $SCRIPT_NAME..."

# Use the VENV_PYTHON path to launch the script
$VENV_PYTHON "$SCRIPT_NAME" &
GUI_PID=$!
wait $GUI_PID

echo "--- Remote Linux Manager Finished ---"
