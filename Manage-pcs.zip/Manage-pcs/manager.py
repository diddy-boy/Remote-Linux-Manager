#!/usr/bin/env python3
import warnings
import sys
import sqlite3
import threading
import os
import paramiko
import time
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from datetime import datetime

# --- TKINTER Import (STANDARD LIBRARY ONLY) ---
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import font as tkfont # Import font for style control

# --- Custom Styling Configuration (New Professional Palette) ---
BG_PRIMARY = '#2b2b2b'      # Main background color (Dark Gray)
BG_SECONDARY = '#3c3c3c'    # Widget/List background (Slightly Lighter Gray)
BG_LOG = '#1e1e1e'          # Log background (Deepest Black/Gray for contrast)
FG_PRIMARY = '#e0e0e0'      # Light text color
ACCENT_BLUE = '#007ACC'     # Professional Blue (Selection/Accent)

# Button Color Definitions (Using the refined accent colors)
BUTTON_GREEN = '#4CAF50'        # Flat Green
BUTTON_GREEN_HOVER = '#66BB6A'

BUTTON_RED = '#E53935'          # Flat Red
BUTTON_RED_HOVER = '#EF5350'

BUTTON_BLUE = ACCENT_BLUE       # Accent Blue
BUTTON_BLUE_HOVER = '#3399DD'

BUTTON_ORANGE = '#FF9800'       # Warning Orange
BUTTON_ORANGE_HOVER = '#FFB74D'

# --- Warning Suppression ---
warnings.filterwarnings("ignore", category=DeprecationWarning)

# --- Global Config ---
APP_NAME = "Remote Linux Manager"
DB_NAME = "pc_manager.db"
KEY_FILE = ".secret.key"
SSH_CONNECT_TIMEOUT = 10
MONITOR_POLL_INTERVAL_SECONDS = 10 # Used for reboot/shutdown monitoring

# --- Encryption Utility (No Change) ---
class EncryptionUtility:
    def __init__(self, key_file=KEY_FILE):
        self.key_file = key_file
        self._ensure_key()
        self.fernet = Fernet(self.key)

    def _ensure_key(self):
        if os.path.exists(self.key_file):
            with open(self.key_file, "rb") as f:
                self.key = f.read()
            print("[INFO] Encryption key loaded.")
        else:
            self.key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(self.key)
            print("[INFO] New encryption key generated and saved.")

    def encrypt(self, data):
        return self.fernet.encrypt(data.encode())

    def decrypt(self, token):
        try:
            return self.fernet.decrypt(token).decode()
        except Exception as e:
            print(f"[ERROR] Decryption failed: {e}", file=sys.stderr)
            return None


# --- Database Manager (No Change) ---
class DBManager:
    def __init__(self, db_name=DB_NAME):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS pcs (
                id INTEGER PRIMARY KEY,
                hostname TEXT NOT NULL,
                username TEXT NOT NULL,
                password_encrypted BLOB NOT NULL,
                alias TEXT,
                status TEXT,
                last_update TEXT,
                pending_updates INTEGER DEFAULT 0
            )
        """
        )
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS software_snapshots (
                id INTEGER PRIMARY KEY,
                pc_id INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                package_list TEXT NOT NULL,
                FOREIGN KEY (pc_id) REFERENCES pcs(id)
            )
        """
        )
        self.conn.commit()
        try:
            self.cursor.execute("SELECT pending_updates FROM pcs LIMIT 1")
        except sqlite3.OperationalError:
            self.cursor.execute("ALTER TABLE pcs ADD COLUMN pending_updates INTEGER DEFAULT 0")
            self.conn.commit()
        print("[INFO] Database table ensured.")

    def get_all_pcs(self):
        self.cursor.execute(
            "SELECT id, hostname, username, password_encrypted, alias, status, last_update, pending_updates FROM pcs ORDER BY alias, hostname"
        )
        return self.cursor.fetchall()

    def add_pc(self, hostname, username, encrypted_password, alias):
        self.cursor.execute(
            "INSERT INTO pcs (hostname, username, password_encrypted, alias, status, last_update, pending_updates) VALUES (?, ?, ?, ?, 'Unknown', 'N/A', 0)",
            (hostname, username, encrypted_password, alias),
        )
        self.conn.commit()
        return self.cursor.lastrowid

    def delete_pc(self, pc_id):
        self.cursor.execute("DELETE FROM pcs WHERE id=?", (pc_id,))
        self.conn.commit()

    def update_status(self, pc_id, status, last_update, pending_updates=0):
        self.cursor.execute(
            "UPDATE pcs SET status=?, last_update=?, pending_updates=? WHERE id=?",
            (status, last_update, pending_updates, pc_id),
        )
        self.conn.commit()

    def update_pc(self, pc_id, hostname, username, encrypted_password, alias):
        """Updates an existing PC's details."""
        self.cursor.execute(
            "UPDATE pcs SET hostname=?, username=?, password_encrypted=?, alias=? WHERE id=?",
            (hostname, username, encrypted_password, alias, pc_id),
        )
        self.conn.commit()

    def delete_all_snapshots_for_pc(self, pc_id):
        """Deletes all existing software snapshots for a specific PC ID."""
        self.cursor.execute("DELETE FROM software_snapshots WHERE pc_id=?", (pc_id,))
        self.conn.commit()

    def save_snapshot(self, pc_id, package_list_data):
        self.delete_all_snapshots_for_pc(pc_id)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute(
            "INSERT INTO software_snapshots (pc_id, timestamp, package_list) VALUES (?, ?, ?)",
            (pc_id, timestamp, package_list_data),
        )
        self.conn.commit()

    def get_latest_snapshot(self, pc_id):
        self.cursor.execute(
            "SELECT package_list FROM software_snapshots WHERE pc_id=? ORDER BY timestamp DESC LIMIT 1",
            (pc_id,),
        )
        result = self.cursor.fetchone()
        return result[0] if result else None

    def get_latest_snapshot_timestamp(self, pc_id):
        """Retrieves the timestamp of the latest software snapshot for a given PC."""
        self.cursor.execute(
            "SELECT timestamp FROM software_snapshots WHERE pc_id=? ORDER BY timestamp DESC LIMIT 1",
            (pc_id,),
        )
        result = self.cursor.fetchone()
        return result[0] if result else "N/A"


# ----------------------------------------------------------------------
# --- Add PC Dialog Class (TKINTER TOPLEVEL) ---
# ----------------------------------------------------------------------
class AddPCDialog(tk.Toplevel):
    def __init__(self, parent, is_edit=False):
        super().__init__(parent)
        self.title("Edit PC Details" if is_edit else "Add New PC")
        self.transient(parent)
        self.grab_set()
        self.parent = parent
        self.result = None
        self.data = {}

        # Apply dark mode background
        self.config(bg=BG_PRIMARY)
        self.minsize(600, 200)

        main_frame = ttk.Frame(self, padding="15", style='Dark.TFrame')
        main_frame.pack(fill='both', expand=True)

        grid = ttk.Frame(main_frame, style='Dark.TFrame')
        grid.pack(pady=10)

        fields = [
            ("Alias:", "alias_entry"),
            ("Hostname or IP:", "hostname_entry"),
            ("Username:", "username_entry"),
            ("Password:", "password_entry"),
        ]

        self.entries = {}
        for i, (label_text, entry_key) in enumerate(fields):
            # Use Dark.TLabel
            label = ttk.Label(grid, text=label_text, style='Dark.TLabel')
            label.grid(row=i, column=0, sticky='e', padx=5, pady=5)

            # Use TEntry (styling often left to OS)
            entry = ttk.Entry(grid, width=40, style='Dark.TEntry')

            if entry_key == "password_entry":
                entry.config(show='*')
                if is_edit:
                    entry.insert(0, "(Leave blank to keep existing password)")
            
            self.entries[entry_key] = entry
            entry.grid(row=i, column=1, sticky='we', padx=5, pady=5)
        
        button_frame = ttk.Frame(main_frame, style='Dark.TFrame')
        button_frame.pack(fill='x', pady=10)

        # Use standard TButton style
        ok_button = ttk.Button(button_frame, text="OK", command=self.on_ok, style='TButton')
        ok_button.pack(side='right', padx=5)

        cancel_button = ttk.Button(button_frame, text="Cancel", command=self.destroy, style='TButton')
        cancel_button.pack(side='right', padx=5)

        self.protocol("WM_DELETE_WINDOW", self.destroy)

        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = parent.winfo_x() + parent.winfo_width() // 2 - width // 2
        y = parent.winfo_y() + parent.winfo_height() // 2 - height // 2
        self.geometry(f'+{x}+{y}')

    def on_ok(self):
        self.data = {key.replace('_entry', ''): entry.get().strip()
                     for key, entry in self.entries.items()}
        self.result = "ok"
        self.destroy()

    def show(self):
        self.wait_window(self)
        return self.result, self.data


# ----------------------------------------------------------------------
# --- Deploy Software Dialog Class (TKINTER TOPLEVEL) ---
# ----------------------------------------------------------------------
class DeploySoftwareDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Deploy Software to Selected PCs")
        self.transient(parent)
        self.grab_set()
        self.parent = parent
        self.result = None
        self.packages = []
        
        # Define the placeholder text and colors
        self.placeholder_text = "e.g., htop git vim"
        self.placeholder_color = '#888888' # A lighter color for placeholder
        self.default_color = FG_PRIMARY     # Original text color
        
        # Apply dark mode background
        self.config(bg=BG_PRIMARY)
        self.minsize(450, 200)

        main_frame = ttk.Frame(self, padding="15", style='Dark.TFrame')
        main_frame.pack(fill='both', expand=True)

        info_label = ttk.Label(main_frame, text="Enter software package names (separated by space or comma):", style='Dark.TLabel')
        info_label.pack(anchor='w', pady=5)

        # --- MODIFICATION START ---
        # Set width to 50 characters to increase size
        self.software_entry = ttk.Entry(main_frame, width=50)
        self.software_entry.pack(fill='x', pady=5)
        # --- MODIFICATION END ---
        
        # Set up the initial placeholder state and bind the focus event
        self.setup_placeholder() 
        self.software_entry.bind('<FocusIn>', self.on_entry_focus)

        button_frame = ttk.Frame(main_frame, style='Dark.TFrame')
        button_frame.pack(fill='x', pady=10)

        # Deploy Button uses default TButton style
        ok_button = ttk.Button(button_frame, text="Deploy", command=self.on_deploy, style='TButton')
        ok_button.pack(side='right', padx=5)

        cancel_button = ttk.Button(button_frame, text="Cancel", command=self.destroy, style='TButton')
        cancel_button.pack(side='right', padx=5)
        
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = parent.winfo_x() + parent.winfo_width() // 2 - width // 2
        y = parent.winfo_y() + parent.winfo_height() // 2 - height // 2
        self.geometry(f'+{x}+{y}')

    def setup_placeholder(self):
        """Initializes the entry with the placeholder text and style."""
        style = ttk.Style()
        # --- MODIFICATION START ---
        # Create a style for the placeholder text (lighter color and larger font)
        style.configure('Placeholder.TEntry', 
                        foreground=self.placeholder_color, 
                        background=BG_SECONDARY, 
                        fieldbackground=BG_SECONDARY,
                        font=('Helvetica', 14) # Increased font size
                       )
        
        self.software_entry.insert(0, self.placeholder_text)
        self.software_entry.configure(style='Placeholder.TEntry')
        # --- MODIFICATION END ---

    def on_entry_focus(self, event):
        """Clears the placeholder text when the entry field receives focus."""
        if self.software_entry.get() == self.placeholder_text:
            self.software_entry.delete(0, 'end')  # Clear the text
            
            # Change the style back to the default one for user input
            style = ttk.Style()
            # --- MODIFICATION START ---
            # Create a style for user input (default color and larger font)
            style.configure('User.TEntry', 
                            foreground=self.default_color, 
                            background=BG_SECONDARY, 
                            fieldbackground=BG_SECONDARY,
                            font=('Helvetica', 14) # Increased font size
                           )
            self.software_entry.configure(style='User.TEntry')
            # --- MODIFICATION END ---

    def on_deploy(self):
        text = self.software_entry.get().strip()
        
        # Check if the text is empty OR still the placeholder text
        if not text or text == self.placeholder_text:
            messagebox.showerror("Error", "Package list cannot be empty.")
            return

        self.packages = text.replace(',', ' ').split()
        self.result = "deploy"
        self.destroy()

    def show(self):
        self.wait_window(self)
        return self.result, self.packages


# ----------------------------------------------------------------------
# --- NEW: Run Command Dialog Class (TKINTER TOPLEVEL) ---
# ----------------------------------------------------------------------
class RunCommandDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Run Remote Command")
        self.transient(parent)
        self.grab_set()
        self.parent = parent
        self.result = None
        self.command = ""
        # Default to using sudo for safety/flexibility of running shell commands
        self.use_sudo = tk.BooleanVar(value=True) 

        # Apply dark mode background
        self.config(bg=BG_PRIMARY)
        self.minsize(550, 250)

        main_frame = ttk.Frame(self, padding="15", style='Dark.TFrame')
        main_frame.pack(fill='both', expand=True)

        info_label = ttk.Label(main_frame, text="Enter the command to execute on selected PCs:", style='Dark.TLabel')
        info_label.pack(anchor='w', pady=(0, 5))

        # Use a Text widget for potentially multi-line commands and better input experience
        command_frame = ttk.Frame(main_frame, style='Dark.TFrame')
        command_frame.pack(fill='both', expand=True, pady=5)

        self.command_text = tk.Text(command_frame, wrap='word', height=5, 
                                bg=BG_SECONDARY, fg=FG_PRIMARY, insertbackground=FG_PRIMARY, 
                                borderwidth=1, relief='solid', font=('Consolas', 11)
                                )
        self.command_text.pack(side='left', fill='both', expand=True)
        
        # Sudo Checkbox
        sudo_check = ttk.Checkbutton(main_frame, text="Run with sudo (recommended)", variable=self.use_sudo, style='Dark.TLabel')
        sudo_check.pack(anchor='w', pady=(10, 5))

        button_frame = ttk.Frame(main_frame, style='Dark.TFrame')
        button_frame.pack(fill='x', pady=10)

        run_button = ttk.Button(button_frame, text="Run Command", command=self.on_run, style='TButton')
        run_button.pack(side='right', padx=5)

        cancel_button = ttk.Button(button_frame, text="Cancel", command=self.destroy, style='TButton')
        cancel_button.pack(side='right', padx=5)
        
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = parent.winfo_x() + parent.winfo_width() // 2 - width // 2
        y = parent.winfo_y() + parent.winfo_height() // 2 - height // 2
        self.geometry(f'+{x}+{y}')

    def on_run(self):
        # Retrieve content from text widget
        self.command = self.command_text.get("1.0", 'end-1c').strip() 
        
        if not self.command:
            messagebox.showerror("Error", "Command cannot be empty.")
            return

        self.result = "run"
        self.destroy() # Closes the window after getting the result

    def show(self):
        self.wait_window(self)
        return self.result, self.command, self.use_sudo.get()


# ----------------------------------------------------------------------
# --- Main Window Class (TKINTER) ---
# ----------------------------------------------------------------------
class PCManager:
    def __init__(self, master, db_manager):
        self.master = master
        self.db_manager = db_manager
        self.pc_list_data = []
        self.monitoring_pcs = {}
        self.encryption_util = EncryptionUtility()
        self.selected_pc_ids = []

        self.master.title(APP_NAME)
        self.master.geometry("850x700") 
        self.master.minsize(800, 600) 
        self.master.protocol("WM_DELETE_WINDOW", self._on_closing)

        # Apply dark mode background to the root window
        self.master.config(bg=BG_PRIMARY)
        self.setup_styles()

        # Use a main frame with dark styling
        main_frame = ttk.Frame(master, style='Dark.TFrame')
        main_frame.pack(fill='both', expand=True, padx=12, pady=12)

        self.setup_ui(main_frame)
        self.load_pc_data()
        
        self.log_message(f"[{APP_NAME}] Initialized.")
        
        self.master.after(1000, lambda: self.on_refresh_clicked(None))


    def setup_styles(self):
        style = ttk.Style()
        
        # 1. Use the "clam" theme for best customization control
        try:
            style.theme_use('clam')
        except tk.TclError:
             style.theme_use('default') 
             
        # Define a professional, clean font preference
        FONT_FAMILY = ('Helvetica', 'Arial', 'TkDefaultFont')
        
        # 2. Configure UNIVERSAL Styles
        style.configure('.', font=(FONT_FAMILY, 10))
        
        # 3. Configure Dark Style for Frames, Labels, and Scrollbars
        style.configure('Dark.TFrame', background=BG_PRIMARY)
        style.configure('Dark.TLabel', background=BG_PRIMARY, foreground=FG_PRIMARY, font=(FONT_FAMILY, 10, 'bold'))
        style.configure('Vertical.TScrollbar', background=BG_PRIMARY, troughcolor=BG_PRIMARY, arrowcolor=FG_PRIMARY)
        
        # 4. Configure Entry/Input Fields for Dark Mode
        # The base TEntry style is now configured here:
        style.configure('TEntry', background=BG_SECONDARY, fieldbackground=BG_SECONDARY, foreground=FG_PRIMARY, bordercolor=BG_PRIMARY)
        
        # 5. Configure Treeview (List) for Professional Dark Mode
        style.configure("Treeview", 
                        background=BG_SECONDARY,  
                        foreground=FG_PRIMARY,
                        fieldbackground=BG_SECONDARY,
                        bordercolor=BG_PRIMARY,
                        borderwidth=0,
                        rowheight=25 # Increased row height for better spacing
        )
        style.map('Treeview', 
                 background=[('selected', ACCENT_BLUE)], # Professional Blue selection
                 foreground=[('selected', 'white')]
        )
        style.configure("Treeview.Heading", 
                        background=BG_PRIMARY,  # Header background same as main frame
                        foreground=FG_PRIMARY, 
                        relief="flat",
                        font=(FONT_FAMILY, 10, 'bold')
        )
        
        # 6. Define BASE Button Config for a highlighted look
        HIGHLIGHT_BORDER_COLOR = ACCENT_BLUE 
        
        BASE_BUTTON_SHARED_CONFIG = {
            'bordercolor': HIGHLIGHT_BORDER_COLOR, 
            'borderwidth': 2,                      # Set to 2 for a visible border highlight
            'relief': "raised",                    # Use 'raised' to force the border to draw on Windows
            'padding': [12, 6]                     # Professional padding
        }
        
        # 6a. Configure Standard TButton (ACCENT_BLUE for primary actions)
        style.configure('TButton', 
                        background=ACCENT_BLUE, 
                        foreground='white',
                        **BASE_BUTTON_SHARED_CONFIG
        )
        style.map('TButton', 
                  background=[('active', BUTTON_BLUE_HOVER)]
        )

        # 6b. Custom Colored Buttons (Inherit base style, override colors)
        def configure_color_button(name, color, hover_color):
            style.configure(f'{name}.TButton', 
                            background=color, 
                            foreground='white',
                            **BASE_BUTTON_SHARED_CONFIG # Inherits high-contrast border and 'raised' relief
            )
            style.map(f'{name}.TButton', 
                      background=[('active', hover_color)]
            )
        
        configure_color_button('Green', BUTTON_GREEN, BUTTON_GREEN_HOVER)
        configure_color_button('Red', BUTTON_RED, BUTTON_RED_HOVER)
        configure_color_button('Blue', BUTTON_BLUE, BUTTON_BLUE_HOVER)
        configure_color_button('Orange', BUTTON_ORANGE, BUTTON_ORANGE_HOVER)


    def setup_ui(self, parent_frame):
        
        # --- Treeview Setup (PC List) ---
        # This frame is set to expand and will shrink vertically to accommodate the taller log
        tree_frame = ttk.Frame(parent_frame, style='Dark.TFrame')
        tree_frame.pack(fill='both', expand=True, pady=(0, 10))

        columns = ("Alias", "Status", "Pending Updates", "Last Update", "Last Snapshot Created")
        self.pc_list_view = ttk.Treeview(tree_frame, columns=columns, show='headings', selectmode='extended')

        width_map = {
            "Alias": 200,
            "Status": 100,
            "Pending Updates": 120,
            "Last Update": 180,
            "Last Snapshot Created": 180
        }
        for col in columns:
            self.pc_list_view.heading(col, text=col)
            self.pc_list_view.column(col, width=width_map[col], anchor='center')

        # Scrollbar for Treeview, using our styled scrollbar
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.pc_list_view.yview, style='Vertical.TScrollbar')
        vsb.pack(side='right', fill='y')
        self.pc_list_view.configure(yscrollcommand=vsb.set)
        self.pc_list_view.pack(side='left', fill='both', expand=True)

        self.pc_list_view.bind('<<TreeviewSelect>>', self.on_selection_changed)

        # --- Button Rows (Styled Frames - 3 Rows) ---
        button_vbox = ttk.Frame(parent_frame, style='Dark.TFrame')
        button_vbox.pack(fill='x', pady=5)
        
        # Row 1: Management
        row_management = ttk.Frame(button_vbox, style='Dark.TFrame')
        row_management.pack(fill='x', pady=3)
        
        # Row 2: Maintenance (Includes the new 'Run Command' button)
        row_maintenance = ttk.Frame(button_vbox, style='Dark.TFrame')
        row_maintenance.pack(fill='x', pady=3)
        
        # Row 3: Control/Snapshots
        row_control = ttk.Frame(button_vbox, style='Dark.TFrame')
        row_control.pack(fill='x', pady=3)

        # Define the buttons and their specific styles
        button_map = {
            # Row 1: PC Management/Configuration
            "Add PC": {"handler": self.on_add_pc_clicked, "row": row_management, "style": 'TButton'},
            "Edit PC": {"handler": self.on_edit_pc_clicked, "row": row_management, "style": 'TButton'},
            "Delete PC": {"handler": lambda: self._show_confirmation_dialog("delete", "Delete"), "row": row_management, "style": 'Orange.TButton'},
            "Clone PC": {"handler": lambda: self._show_confirmation_dialog("clone", "Clone"), "row": row_management, "style": 'TButton'},
            
            # Row 2: Status/Maintenance
            "Check Status": {"handler": self.on_refresh_clicked, "row": row_maintenance, "style": 'Green.TButton'}, 
            "Run Update": {"handler": lambda: self._show_confirmation_dialog("update", "Run Update"), "row": row_maintenance, "style": 'TButton'},
            "Deploy Software": {"handler": self.on_deploy_software_clicked, "row": row_maintenance, "style": 'TButton'}, 
            "Run Command": {"handler": self.on_run_command_clicked, "row": row_maintenance, "style": 'TButton'}, # NEW BUTTON
            
            # Row 3: System Control/Snapshots
            "Create Snapshot": {"handler": lambda: self._show_confirmation_dialog("create_snapshot", "Create Snapshot"), "row": row_control, "style": 'Blue.TButton'},
            "Revert to snapshot": {"handler": lambda: self._show_confirmation_dialog("revert", "Revert"), "row": row_control, "style": 'Blue.TButton'},
            "Reboot PC": {"handler": lambda: self._show_confirmation_dialog("reboot", "Reboot"), "row": row_control, "style": 'Red.TButton'},     
            "Shutdown PC": {"handler": lambda: self._show_confirmation_dialog("shutdown", "Shutdown"), "row": row_control, "style": 'Red.TButton'}, 
        }

        # New button orders reflecting 3 rows
        button_order_1 = ["Add PC", "Edit PC", "Delete PC", "Clone PC"]
        button_order_2 = ["Check Status", "Run Update", "Deploy Software", "Run Command"]
        button_order_3 = ["Create Snapshot", "Revert to snapshot", "Reboot PC", "Shutdown PC"]

        # Helper to create buttons with custom styles
        def create_buttons(order, row_frame):
            for label in order:
                b_info = button_map.get(label)
                # All buttons in the row get equal weight via expand=True, fill='x'
                b = ttk.Button(row_frame, text=label, command=b_info["handler"], style=b_info["style"])
                b.pack(side='left', padx=5, pady=5, expand=True, fill='x')

        create_buttons(button_order_1, row_management)
        create_buttons(button_order_2, row_maintenance)
        create_buttons(button_order_3, row_control)

        # --- Log View Setup ---
        log_frame = ttk.Frame(parent_frame, style='Dark.TFrame')
        # This frame is set to NOT expand (expand=False) and its height is controlled by the tk.Text widget's height
        log_frame.pack(fill='both', expand=False, pady=(10, 0))
        
        # Use Dark.TLabel with primary BG
        ttk.Label(log_frame, text="Log Output:", style='Dark.TLabel').pack(anchor='w', pady=(0, 2))

        # Use tk.Text with deepest BG_LOG color for high contrast
        self.log_view = tk.Text(log_frame, state='disabled', wrap='word', height=15, 
                                bg=BG_LOG, fg=FG_PRIMARY, insertbackground=FG_PRIMARY, 
                                borderwidth=0, highlightthickness=0, font=('Consolas', 10) # Monospace font for logs
                                )
        
        log_vsb = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_view.yview, style='Vertical.TScrollbar')
        self.log_view.configure(yscrollcommand=log_vsb.set)

        log_vsb.pack(side='right', fill='y')
        self.log_view.pack(side='left', fill='both', expand=True)


    def _on_closing(self):
        self.log_message("[INFO] Application closed.")
        self.master.destroy()

    def log_message(self, message):
        def append():
            now = datetime.now().strftime("[%H:%M:%S]")
            self.log_view.config(state='normal')
            
            # Check if the scrollbar is near the bottom (1.0 is the end). Use a threshold like 0.9.
            at_bottom = self.log_view.yview()[1] > 0.9 
            
            self.log_view.insert('end', f"{now} {message}\n")
            
            # Only auto-scroll if the user was already near the bottom
            if at_bottom:
                self.log_view.see('end')

            self.log_view.config(state='disabled')
        
        self.master.after(0, append)

    def _get_current_time_str(self, mask="%Y-%m-%d %H:%M:%S"):
        return datetime.now().strftime(mask)

    def load_pc_data(self):
        self.pc_list_data.clear()
        self.pc_list_view.delete(*self.pc_list_view.get_children())

        for idx, row in enumerate(self.db_manager.get_all_pcs()):
            if len(row) == 7:
                pc_id, host, user, enc, alias, status, last = row
                pending = 0
            else:
                pc_id, host, user, enc, alias, status, last, pending = row
            
            last_snapshot_date = self.db_manager.get_latest_snapshot_timestamp(pc_id)

            data_entry = dict(id=pc_id, hostname=host, username=user, password_encrypted=enc,
                     alias=alias, status=status, last_update=last,
                     pending_updates=pending, index=idx,
                     last_snapshot_date=last_snapshot_date)
            
            self.pc_list_data.append(data_entry)
            
            tree_values = (alias, status, pending, last, last_snapshot_date)
            self.pc_list_view.insert('', 'end', iid=pc_id, values=tree_values)

    def on_selection_changed(self, event):
        selected_iids = self.pc_list_view.selection()
        self.selected_pc_ids = [int(iid) for iid in selected_iids]
        
    def _show_confirmation_dialog(self, action, label):
        target_ids = self.selected_pc_ids
        
        if not target_ids:
            # New logic for "Run Update" to update ALL if nothing is selected
            if action == "update" and messagebox.askyesno(
                "Confirm Update ALL",
                "WARNING: No PC is selected.\n\n"
                "Do you want to run 'apt update' and 'apt upgrade -y' on *ALL* listed PCs?"
            ):
                pc_list = self.pc_list_data
                if pc_list:
                    self.log_message(f"[INFO] Running Update ALL on {len(pc_list)} PCs.")
                    self.run_mass_action_thread(pc_list, "update")
                else:
                    self.log_message("[ERROR] No PCs available in the list to update.")
                return
            
            self.log_message(f"[ERROR] Select a PC first to {action.replace('_', ' ').lower()}.")
            return

        dialog_title = f"Confirm {label}"
        sec = ""
        
        if action == "create_snapshot":
            if len(target_ids) != 1:
                self.log_message(f"[ERROR] Snapshot creation requires selecting exactly ONE PC.")
                return
            pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            alias = pc["alias"] if pc else f"ID {target_ids[0]}"
            msg = f"Confirm new snapshot CREATION for {alias.upper()}?"
            sec = "A snapshot of the installed software list will be saved to the database, replacing any previous snapshot for this PC."
            dialog_title = "Confirm Software Snapshot Creation"
        
        elif action == "clone":
            if len(target_ids) != 2:
                self.log_message(f"[ERROR] Cloning requires selecting exactly TWO PCs: the Source and the Target.")
                return
            source_pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), {"alias": f"ID {target_ids[0]}"})
            target_pc = next((p for p in self.pc_list_data if p["id"] == target_ids[1]), {"alias": f"ID {target_ids[1]}"})
            msg = f"Are you sure you want to clone from PC {source_pc['alias'].upper()} to PC {target_pc['alias'].upper()}?"
            sec = "WARNING: This will deploy all packages from the SOURCE PC to the TARGET PC. This cannot be easily undone."
            dialog_title = "Confirm PC Clone Deployment"

        elif action == "revert":
            if len(target_ids) > 1:
                self.log_message(f"[ERROR] Reverting a snapshot can only be performed on a single PC at a time.")
                return
            pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            alias = pc["alias"] if pc else f"ID {target_ids[0]}"
            msg = f"Confirm REVERT to snapshot for {alias.upper()}?"
            sec = "WARNING: This action will remove all software installed since the last snapshot. This cannot be undone."
            dialog_title = "Confirm Software Snapshot Revert"

        else:
            if len(target_ids) > 1:
                alias = f"{len(target_ids)} PC(s)"
                op_name = label.lower()
                msg = f"Are you sure you want to {op_name} {alias}?"
                if action == "shutdown":
                    sec = "This will power off all selected PCs. Monitoring will track loss of connection."
                elif action == "reboot":
                    sec = "This will restart all selected PCs. Monitoring will track connection loss and recovery."
                elif action == "update": 
                    sec = "This will run 'apt update' and 'apt upgrade -y' on all selected PCs."
            else:
                pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
                alias = pc["alias"] if pc else f"ID {target_ids[0]}"
                op_name = label.lower().replace(" run", "")
                msg_map = { 
                    "delete": (f"Are you sure you want to {op_name} {alias}?", "This removes it from the list only."),
                    "shutdown": (f"Are you sure you want to {op_name} {alias}?", "Monitoring will track loss of connection."),
                    "reboot": (f"Are you sure you want to {op_name} {alias}?", "Monitoring will track connection loss and recovery."),
                    "update": (f"Are you sure you want to update {alias}?", "This will run 'apt update' and 'apt upgrade -y'.")
                }
                msg, sec = msg_map.get(action, (f"Confirm {op_name} on {alias}?", ""))
        
        full_message = f"{msg}\n\n{sec}"
        
        if messagebox.askyesno(dialog_title, full_message):
            if action == "delete":
                self.on_delete_pc_clicked(target_ids)
            elif action == "clone":
                self.run_clone_action(target_ids)
            elif action == "revert":
                self.run_revert_action(target_ids)
            elif action == "create_snapshot":
                self.run_create_snapshot_action(target_ids)
            else:
                pc_list = [p for p in self.pc_list_data if p["id"] in target_ids]
                self.run_mass_action_thread(pc_list, action)
        else:
            self.log_message(f"[INFO] {action.replace('_', ' ').capitalize()} cancelled.")

    # --- Action Handlers (No Change) ---
    def on_add_pc_clicked(self, event=None):
        dialog = AddPCDialog(self.master)
        result, data = dialog.show()
        
        if result == "ok" and data['hostname'] and data['username'] and data['password']:
            try:
                encrypted_password = self.encryption_util.encrypt(data['password'])
                self.db_manager.add_pc(data['hostname'], data['username'], encrypted_password, data['alias'])
                self.log_message(f"[INFO] Added new PC: {data['alias']}")
                self.load_pc_data()
            except Exception as e:
                self.log_message(f"[ERROR] Failed to add PC: {e}")

    def on_edit_pc_clicked(self, event=None):
        if len(self.selected_pc_ids) != 1:
            self.log_message("[ERROR] Select exactly ONE PC to edit.")
            return

        pc_id = self.selected_pc_ids[0]
        pc_info = next((p for p in self.pc_list_data if p["id"] == pc_id), None)

        if not pc_info:
            self.log_message(f"[ERROR] PC with ID {pc_id} not found.")
            return

        dialog = AddPCDialog(self.master, is_edit=True)
        dialog.entries['alias_entry'].delete(0, 'end')
        dialog.entries['alias_entry'].insert(0, pc_info['alias'])
        dialog.entries['hostname_entry'].delete(0, 'end')
        dialog.entries['hostname_entry'].insert(0, pc_info['hostname'])
        dialog.entries['username_entry'].delete(0, 'end')
        dialog.entries['username_entry'].insert(0, pc_info['username'])

        result, data = dialog.show()

        if result == "ok" and data['hostname'] and data['username']:
            new_password = data['password']
            if new_password and "(Leave blank to keep existing password)" not in new_password:
                encrypted_password = self.encryption_util.encrypt(new_password)
            else:
                encrypted_password = pc_info['password_encrypted']

            try:
                self.db_manager.update_pc(pc_id, data['hostname'], data['username'], encrypted_password, data['alias'])
                self.log_message(f"[INFO] Updated PC: {data['alias']}")
                self.load_pc_data()
            except Exception as e:
                self.log_message(f"[ERROR] Failed to update PC: {e}")

    def on_delete_pc_clicked(self, target_ids):
        for pc_id in target_ids:
            try:
                self.db_manager.delete_pc(pc_id)
                self.pc_list_data = [p for p in self.pc_list_data if p["id"] != pc_id]
                self.pc_list_view.delete(str(pc_id))
                self.log_message(f"[INFO] Deleted PC ID: {pc_id}")
            except Exception as e:
                self.log_message(f"[ERROR] Failed to delete PC ID {pc_id}: {e}")
                
    def on_deploy_software_clicked(self, event=None):
        dialog = DeploySoftwareDialog(self.master)
        result, packages = dialog.show()
        
        if result == "deploy" and packages:
            # Determine target PC list based on selection
            if not self.selected_pc_ids:
                # If nothing is selected, deploy to ALL known PCs
                pc_list = self.pc_list_data
                self.log_message(f"[INFO] No selection made. Deploying to ALL {len(pc_list)} PCs.")
            else:
                # Otherwise, deploy only to selected PCs
                pc_list = [p for p in self.pc_list_data if p["id"] in self.selected_pc_ids]
                self.log_message(f"[INFO] Deploying to {len(pc_list)} selected PC(s).")

            if not pc_list:
                 self.log_message("[ERROR] No PCs available in the list to deploy software.")
                 return
                 
            # ----------------------------------------------------------------------------------
            # *** FIX: Use a single 'sudo sh -c' to prevent re-authentication issues with '&&' ***
            # ----------------------------------------------------------------------------------
            packages_str = ' '.join(packages)
            full_script = (
                f"DEBIAN_FRONTEND=noninteractive apt update && "
                f"DEBIAN_FRONTEND=noninteractive apt install -y {packages_str}"
            )
            # The inner logic of _run_ssh_command will apply -S to this single sudo call
            command = f"sudo sh -c '{full_script}'"
            # ----------------------------------------------------------------------------------
            
            self.run_mass_action_thread(pc_list, "deploy", command=command)

    # --- NEW: on_run_command_clicked method ---
    def on_run_command_clicked(self, event=None):
        dialog = RunCommandDialog(self.master)
        result, command, use_sudo = dialog.show()
        
        # Dialog automatically closes in on_run, fulfilling the user requirement
        
        if result == "run" and command:
            # Determine target PC list based on selection
            if not self.selected_pc_ids:
                # If nothing is selected, run on ALL known PCs
                pc_list = self.pc_list_data
                self.log_message(f"[INFO] No selection made. Running command on ALL {len(pc_list)} PCs.")
            else:
                # Otherwise, run only on selected PCs
                pc_list = [p for p in self.pc_list_data if p["id"] in self.selected_pc_ids]
                self.log_message(f"[INFO] Running command on {len(pc_list)} selected PC(s).")

            if not pc_list:
                 self.log_message("[ERROR] No PCs available in the list to run command.")
                 return
            
            # 1. Prepare the final command (Robustness Fix)
            final_command = command
            if use_sudo:
                # Check if the command already has a sudo (case-insensitive)
                if 'sudo' not in command.lower():
                    # Wrap the entire command using the shell execution trick (best for non-interactive)
                    final_command = f"sudo sh -c '{command}'"
                # If it already has sudo, the _run_ssh_command will handle sudo -S

            self.log_message(f"[CMD] Executing: {final_command}")
            
            # 2. Run the command using the mass action thread
            # Use action "run_command" to ensure correct logging and status handling below
            self.run_mass_action_thread(pc_list, "run_command", command=final_command)


    # --- New Connection/Monitoring Methods ---

    def _can_connect(self, pc_info, timeout=2):
        """Attempts a quick SSH connection to see if the PC is network-reachable."""
        host = pc_info["hostname"]
        user = pc_info["username"]
        connect_host = host if '.' in host else f"{host}.local"
        
        try:
            password = self.encryption_util.decrypt(pc_info["password_encrypted"])
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # Attempt connection only, with a small timeout
            ssh.connect(connect_host, username=user, password=password, timeout=timeout)
            ssh.close()
            return True
        except Exception:
            return False

    def _reboot_monitor(self, pc_info, action):
        """
        Dedicated thread to handle the reboot/shutdown action and monitor its status.
        The action is either 'reboot' or 'shutdown'.
        """
        pc_id = pc_info["id"]
        alias = pc_info["alias"]
        
        # 1. Execute the reboot/shutdown command
        cmd = "sudo reboot" if action == "reboot" else "sudo shutdown now"
        
        self.log_message(f"[TASK] Executing {action} command on {alias}...")
        success, status = self._run_ssh_command(pc_info, cmd)

        current_time = self._get_current_time_str()
        
        if not success:
            self.log_message(f"[FAIL] Initial {action} command failed on {alias}: {status}")
            fail_status = f"{action.capitalize()} Cmd Failed"
            self.db_manager.update_status(pc_id, fail_status, current_time, 0)
            self.master.after(0, lambda p=pc_id, s=fail_status, t=current_time, u=0: self._update_pc_row_data(p, s, t, u))
            return

        # 2. Command executed successfully, start monitoring
        monitoring_status = f"{action.capitalize()}ing..."
        self.log_message(f"[MONITOR] {alias} is now {monitoring_status.lower()}. Status set to {monitoring_status}.")
        self.db_manager.update_status(pc_id, monitoring_status, current_time, 0)
        self.master.after(0, lambda p=pc_id, s=monitoring_status, t=current_time, u=0: self._update_pc_row_data(p, s, t, u))

        # 3. Wait for initial connection loss
        # Give the machine a moment to start shutting down (fail quickly)
        time.sleep(MONITOR_POLL_INTERVAL_SECONDS / 2) 

        # 4. Monitoring Loop: Wait for PC to go offline
        self.log_message(f"[MONITOR] Waiting for {alias} to go offline...")
        
        offline_time_start = time.time()
        # Ping check uses a very low timeout (1 sec) for responsiveness
        while self._can_connect(pc_info, timeout=1):
            self.log_message(f"[MONITOR] {alias} is still connected. Waiting for drop...")
            time.sleep(MONITOR_POLL_INTERVAL_SECONDS)
            
            # 5 minutes max to go offline
            if time.time() - offline_time_start > 300: 
                self.log_message(f"[WARN] {alias} failed to go offline after 5 mins. Assuming failed {action} or stuck state.")
                final_status = f"{action.capitalize()} Stuck"
                self.db_manager.update_status(pc_id, final_status, self._get_current_time_str(), 0)
                self.master.after(0, lambda p=pc_id, s=final_status, t=self._get_current_time_str(), u=0: self._update_pc_row_data(p, s, t, u))
                return

        self.log_message(f"[MONITOR] {alias} is offline.")
        
        # If shutdown, stop here.
        if action == "shutdown":
            final_status = "Offline (Shutdown)"
            self.db_manager.update_status(pc_id, final_status, self._get_current_time_str(), 0)
            self.master.after(0, lambda p=pc_id, s=final_status, t=self._get_current_time_str(), u=0: self._update_pc_row_data(p, s, t, u))
            self.log_message(f"[SUCCESS] {alias} has shut down.")
            return

        # 5. Monitoring Loop: Wait for PC to come back online (only for reboot)
        self.log_message(f"[MONITOR] Polling every {MONITOR_POLL_INTERVAL_SECONDS}s for {alias} to reconnect.")
        reconnect_time_start = time.time()
        while not self._can_connect(pc_info):
            self.log_message(f"[MONITOR] {alias} is still offline.")
            time.sleep(MONITOR_POLL_INTERVAL_SECONDS)
            
            if time.time() - reconnect_time_start > 600: # 10 minutes max for reboot
                self.log_message(f"[CRITICAL] {alias} failed to come back online after 10 minutes.")
                final_status = "Reboot Failed"
                self.db_manager.update_status(pc_id, final_status, self._get_current_time_str(), 0)
                self.master.after(0, lambda p=pc_id, s=final_status, t=self._get_current_time_str(), u=0: self._update_pc_row_data(p, s, t, u))
                return

        # 6. Success: PC is online
        pending_updates = self._check_pending_updates_count(pc_info)
        final_status = "OK (Rebooted)"
        current_time = self._get_current_time_str()
        
        self.log_message(f"[SUCCESS] {alias} is back online! Status: {final_status}. Updates pending: {pending_updates}")
        self.db_manager.update_status(pc_id, final_status, current_time, pending_updates)
        self.master.after(0, lambda p=pc_id, s=final_status, t=current_time, u=pending_updates: self._update_pc_row_data(p, s, t, u))


    # --- SSH and Threading Methods (Modified run_mass_action_thread) ---

    def run_mass_action_thread(self, pc_list, action, command=None):
        def action_worker():
            for pc in pc_list:
                # Handle reboot and shutdown with the special monitor thread
                if action in ("reboot", "shutdown"):
                    # Start the monitor in a new thread immediately and continue the loop for other PCs
                    threading.Thread(target=self._reboot_monitor, args=(pc, action)).start()
                    continue
                
                host = pc["hostname"]
                alias = pc["alias"]
                pc_id = pc["id"]
                
                self.log_message(f"[TASK] Starting {action} on {alias} ({host})...")
                self.master.after(0, lambda p=pc_id: self._update_pc_row_status(p, "In Progress", self._get_current_time_str()))

                # --- 1. HANDLE ARBITRARY RUN COMMAND (Uses detailed output logging) ---
                if action == "run_command":
                    # Use the special method that returns output/error streams for detailed logging
                    output, error, success = self._run_ssh_command_with_output(pc, command)
                    
                    current_time = self._get_current_time_str()
                    pending_updates = self._check_pending_updates_count(pc) if success else 0
                    
                    # Log the full output/error from the specific helper function
                    if success:
                        self.log_message(f"[OUTPUT: {alias}] Success (Exit 0).\n{output or '(No output)'}")
                        # If successful, revert status to previous if available, otherwise 'OK'
                        final_status = next((p["status"] for p in self.pc_list_data if p["id"] == pc_id), "OK")
                    else:
                        self.log_message(f"[OUTPUT: {alias}] Failed. Error:\n{error or 'Unknown Error'}")
                        final_status = f"Cmd Failed"

                    self.db_manager.update_status(pc_id, final_status, current_time, pending_updates)
                    self.master.after(0, lambda p=pc_id, s=final_status, t=current_time, u=pending_updates: self._update_pc_row_data(p, s, t, u))
                    self.log_message(f"[COMPLETED] {alias} ({host}) command finished.")
                    continue
                # --- END RUN COMMAND ---
                
                # --- 2. HANDLE STANDARD ACTIONS (update, deploy, check_status) ---
                cmd = None
                if action == "update":
                    # FIX 2: Set DEBIAN_FRONTEND=noninteractive for apt commands
                    cmd = "sudo DEBIAN_FRONTEND=noninteractive apt update && sudo DEBIAN_FRONTEND=noninteractive apt upgrade -y"
                elif action == "deploy":
                    cmd = command
                elif action == "check_status":
                    cmd = "echo OK" # Simple command to check connection
                else:
                    self.log_message(f"[ERROR] Unknown action: {action}")
                    continue

                # Execute using the simpler _run_ssh_command
                success, status = self._run_ssh_command(pc, cmd)
                
                new_status = "OK" if success else f"Failed: {status}"
                current_time = self._get_current_time_str()
                
                pending_updates = 0
                if success:
                    pending_updates = self._check_pending_updates_count(pc)
                    
                # Default status update block (used by update, deploy, check_status)
                self.db_manager.update_status(pc_id, new_status, current_time, pending_updates)
                self.master.after(0, lambda p=pc_id, s=new_status, t=current_time, u=pending_updates: self._update_pc_row_data(p, s, t, u))
                
                self.log_message(f"[COMPLETED] {alias} ({host}) status: {new_status}")
        
        threading.Thread(target=action_worker).start()

    def _update_pc_row_status(self, pc_id, status, last_update):
        iid = str(pc_id)
        if self.pc_list_view.exists(iid):
            current_values = self.pc_list_view.item(iid, 'values')
            if current_values:
                new_values = list(current_values)
                if len(new_values) > 1: new_values[1] = status
                if len(new_values) > 3: new_values[3] = last_update
                self.pc_list_view.item(iid, values=new_values)

    def _update_pc_row_data(self, pc_id, status, last_update, pending_updates=0, last_snapshot_date=None):
        iid = str(pc_id)
        if self.pc_list_view.exists(iid):
            current_values = list(self.pc_list_view.item(iid, 'values'))
            
            current_values[1] = status
            current_values[2] = pending_updates
            current_values[3] = last_update
            
            if len(current_values) > 4 and last_snapshot_date:
                 current_values[4] = last_snapshot_date

            self.pc_list_view.item(iid, values=current_values)
            self.load_pc_data()

    def _run_ssh_command(self, pc_info, command):
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]
        
        connect_host = host if '.' in host else f"{host}.local"
        password = self.encryption_util.decrypt(pc_info["password_encrypted"])

        if not isinstance(password, str):
            self.log_message(f"[FATAL] Auth failed for '{alias}'. Invalid password key.")
            return False, "Authentication Error"

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh.connect(connect_host, username=user, password=password, timeout=SSH_CONNECT_TIMEOUT)
            
            # --- Start Command Execution ---
            if 'sudo' in command.lower():
                # FIX: Ensure -S is used for the FIRST 'sudo' command to allow reading the password 
                # from stdin. This fixes the "a terminal is required" error for non-interactive sessions.
                if 'sudo -S' not in command: 
                    command = command.replace('sudo', 'sudo -S', 1)
                    
                # Execute command without PTY
                stdin, stdout, stderr = ssh.exec_command(command, get_pty=False) 
                
                # Send the password and flush (Crucial: ensure newline is sent)
                # This password will be consumed by the 'sudo -S' command.
                stdin.write(password + '\n') 
                stdin.flush()
                
                # Read all output
                stdout_data = stdout.read().decode().strip()
                stderr_data = stderr.read().decode().strip()

                # Get exit status
                exit_status = stdout.channel.recv_exit_status()
                
            else:
                # Normal command execution
                stdin, stdout, stderr = ssh.exec_command(command)
                stdout_data = stdout.read().decode().strip()
                stderr_data = stderr.read().decode().strip()
                exit_status = stdout.channel.recv_exit_status()

            # --- Output Interpretation (CRUCIAL FIXES FOR APT WARNINGS AND SUDO PROMPT) ---
            
            # 1. Define and filter out benign/expected error messages
            warning_text = 'WARNING: apt does not have a stable CLI interface. Use with caution in scripts.'
            
            # Remove all instances of the warning text from stderr
            clean_stderr = stderr_data.replace(warning_text, '').strip()

            # Filter out the sudo prompt, which might appear in the output on failure
            prompt_text = f"[sudo] password for {user}:"
            clean_stderr = clean_stderr.replace(prompt_text, '').strip()
            
            # Check for generic sudo password failure messages
            if "password is required" in clean_stderr.lower() or "authentication failure" in clean_stderr.lower():
                 self.log_message(f"[SSH FAIL] {alias}: Authentication or Sudo password failed (Exit {exit_status}).")
                 return False, clean_stderr if clean_stderr else "Authentication Failed (Sudo)"

            # Combine output for reporting
            combined_output = f"{stdout_data}\n{clean_stderr}".strip()

            # 2. Check for success (Exit status 0)
            if exit_status == 0:
                self.log_message(f"[SSH OK] {alias} ({command.split()[0]}): Success (Exit 0).")
                return True, combined_output
            
            # FIX: Treat exit status 1 as success for the specific 'grep -c' update count command 
            # when there is no critical error output. grep -c returns 1 if no lines match (i.e., 0 updates).
            update_check_command = "sudo apt list --upgradable 2>/dev/null | grep -c '/'"
            if exit_status == 1 and command == update_check_command and not clean_stderr:
                self.log_message(f"[SSH OK] {alias} (update check): Success (Exit 1 - 0 updates found).")
                return True, combined_output
            
            # 3. Check for non-zero exit status (Failure)
            else:
                # Handle connection drop on reboot/shutdown (it fails with a non-zero exit or exception)
                if 'reboot' in command or 'shutdown' in command:
                    self.log_message(f"[SSH OK] {alias}: Connection dropped after command execution (Expected).")
                    return True, "Connection dropped (Expected)"
                
                # If there is *any* meaningful error left, it's a hard failure.
                if clean_stderr:
                    # Log the original error for debugging but return the cleaned error.
                    self.log_message(f"[SSH FAIL] {alias}: Command failed (Exit {exit_status}). Error: {clean_stderr.splitlines()[-1]}")
                    return False, combined_output
                
                # If exit_status != 0 but clean_stderr is empty, something is fundamentally wrong.
                self.log_message(f"[SSH FAIL] {alias}: Command failed (Exit {exit_status}). No output error.")
                return False, f"Command failed with exit code {exit_status}. No output error.\n{combined_output}"
                
        except paramiko.AuthenticationException:
            self.log_message(f"[SSH FAIL] {alias}: Authentication failed.")
            return False, "Authentication Failed"
        except paramiko.SSHException as e:
            self.log_message(f"[SSH FAIL] {alias}: SSH Error ({e})")
            return False, f"SSH Error: {e}"
        except Exception as e:
            # Catch expected connection drops for reboot/shutdown here as well
            if 'reboot' in command or 'shutdown' in command:
                 if 'connection reset by peer' in str(e).lower() or 'timed out' in str(e).lower() or 'was not established' in str(e).lower():
                    self.log_message(f"[SSH OK] {alias}: Connection dropped after command execution (Expected for {command.split()[1]}).")
                    return True, "Connection dropped (Expected)"
            
            self.log_message(f"[SSH FAIL] {alias}: Connection Error ({e})")
            return False, f"Connection Error: {e}"
        finally:
            # Ensure connection is closed if still open
            try:
                ssh.close()
            except:
                pass


    def _check_pending_updates_count(self, pc_info):
        command = "sudo apt list --upgradable 2>/dev/null | grep -c '/'"
        success, output = self._run_ssh_command(pc_info, command)
        
        # Output might contain extra messages (like the apt warning or combined with grep output).
        # We need to extract the digit.
        if success:
            # Look for the last line which should be the count
            try:
                count = int(output.splitlines()[-1])
                return count
            except (ValueError, IndexError):
                self.log_message(f"[WARN] Failed to parse update count for {pc_info['alias']}. Output: {output}. Assuming 0.")
                return 0
        else:
            self.log_message(f"[WARN] Failed to count updates for {pc_info['alias']}. Assuming 0.")
            return 0
            
    def on_refresh_clicked(self, event=None):
        self.log_message("[INFO] Checking status and pending updates for all PCs...")
        pc_list = self.pc_list_data
        self.run_mass_action_thread(pc_list, "check_status", command="echo OK")

    def _run_ssh_command_with_output(self, pc_info, command):
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]
        connect_host = host if '.' in host else f"{host}.local"
        
        password = self.encryption_util.decrypt(pc_info["password_encrypted"])

        if not isinstance(password, str):
            self.log_message(f"[FATAL] Auth failed for '{alias}'. Invalid password key.")
            return "", "Authentication Error", False

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh.connect(connect_host, username=user, password=password, timeout=SSH_CONNECT_TIMEOUT)
            
            # Apply sudo -S logic for commands that require it
            if 'sudo' in command.lower():
                if 'sudo -S' not in command:
                    command = command.replace('sudo', 'sudo -S', 1) 
                
                stdin, stdout, stderr = ssh.exec_command(command, get_pty=False)
                stdin.write(password + '\n')
                stdin.flush()
            else:
                stdin, stdout, stderr = ssh.exec_command(command)
                
            output = stdout.read().decode().strip()
            error = stderr.read().decode().strip()
            exit_status = stdout.channel.recv_exit_status()

            # Filter benign warnings from error output
            warning_text = 'WARNING: apt does not have a stable CLI interface. Use with caution in scripts.'
            clean_error = error.replace(warning_text, '').strip()

            if exit_status != 0 and clean_error:
                return "", clean_error, False
            
            # Treat success if exit code is 0 OR exit code is non-zero but only warnings were present
            return output, "", True
        
        except Exception as e:
            return "", str(e), False
        finally:
            ssh.close()

    def run_create_snapshot_action(self, target_ids):
        pc_id = target_ids[0]
        pc = next((p for p in self.pc_list_data if p["id"] == pc_id), None)

        def worker():
            self.log_message(f"[TASK] Starting snapshot creation on {pc['alias']}...")
            
            # Command extracts the package name and status, then filters for 'install'
            command = "dpkg --get-selections | awk '{if ($2 == \"install\") print $1}'"
            
            output, error, success = self._run_ssh_command_with_output(pc, command)

            if success and output:
                self.db_manager.save_snapshot(pc_id, output)
                current_time = self._get_current_time_str()
                self.log_message(f"[SUCCESS] Snapshot created for {pc['alias']} at {current_time}. Saved {len(output.splitlines())} packages.")
                self.master.after(0, lambda p=pc_id, t=current_time: self._update_pc_row_data(p, pc['status'], pc['last_update'], pc['pending_updates'], t))
            else:
                self.log_message(f"[FAIL] Snapshot creation failed for {pc['alias']}: {error or 'Unknown SSH Error'}")

        threading.Thread(target=worker).start()

    def run_revert_action(self, target_ids):
        pc_id = target_ids[0]
        pc = next((p for p in self.pc_list_data if p["id"] == pc_id), None)
        
        def worker():
            self.log_message(f"[TASK] Starting differential revert operation on {pc['alias']}...")
            snapshot_packages_raw = self.db_manager.get_latest_snapshot(pc_id)
            if not snapshot_packages_raw:
                self.log_message(f"[FAIL] Revert failed for {pc['alias']}: No snapshot found in database.")
                return

            # snapshot_set is packages NAMES only
            snapshot_set = set(snapshot_packages_raw.splitlines())

            # 1. Get current installed packages (using the same filtered command)
            command_current = "dpkg --get-selections | awk '{if ($2 == \"install\") print $1}'"
            current_packages_raw, error, current_success = self._run_ssh_command_with_output(pc, command_current)
            
            if not current_success:
                self.log_message(f"[FAIL] Revert failed for {pc['alias']}: Could not fetch current package list ({error}).")
                return
                
            # current_set is packages NAMES only
            current_set = set(current_packages_raw.splitlines())
            
            # 2. Calculate the difference: Current Packages MINUS Snapshot Packages
            packages_to_remove = current_set - snapshot_set 
            
            if not packages_to_remove:
                 self.log_message(f"[INFO] {pc['alias']}: System is already at snapshot state. No packages to remove.")
                 new_status = "At Snapshot"
                 current_time = self._get_current_time_str()
                 self.db_manager.update_status(pc_id, new_status, current_time, 0)
                 self.master.after(0, lambda p=pc_id, s=new_status, t=current_time, u=0: self._update_pc_row_data(p, s, t, u))
                 return

            remove_list_str = " ".join(packages_to_remove)
            num_removed = len(packages_to_remove)
            
            self.log_message(f"[INFO] Calculated diff: {num_removed} package(s) to remove from {pc['alias']}.")
            
            # 3. Construct and run the removal command
            # Apply DEBIAN_FRONTEND for non-interactive removal
            removal_script = (
                f"DEBIAN_FRONTEND=noninteractive apt update && "
                f"DEBIAN_FRONTEND=noninteractive apt remove --purge -y {remove_list_str} && "
                f"apt autoremove -y"
            )
            removal_command = f"sudo sh -c '{removal_script}'"

            self.log_message(f"[CMD] {pc['alias']}: Executing removal of {num_removed} packages. The list contains: {' '.join(list(packages_to_remove)[:3])} ...")
            
            success, status = self._run_ssh_command(pc, removal_command) 
            
            current_time = self._get_current_time_str()
            if success:
                # 4. Final status update
                pending_updates = self._check_pending_updates_count(pc)
                new_status = f"Reverted ({num_removed} removed)"
                self.log_message(f"[SUCCESS] Revert operation finished on {pc['alias']}. Updates pending: {pending_updates}.")
                self.db_manager.update_status(pc_id, new_status, current_time, pending_updates)
                self.master.after(0, lambda p=pc_id, s=new_status, t=current_time, u=pending_updates: self._update_pc_row_data(p, s, t, u))
            else:
                new_status = f"Revert Failed: {status.splitlines()[-1]}"
                self.log_message(f"[FAIL] Revert operation failed for {pc['alias']}: {status}")
                self.db_manager.update_status(pc_id, new_status, current_time, 0)
                self.master.after(0, lambda p=pc_id, s=new_status, t=current_time, u=0: self._update_pc_row_data(p, s, t, u))

        threading.Thread(target=worker).start()

    def run_clone_action(self, target_ids):
        source_id = target_ids[0]
        target_id = target_ids[1]
        source_pc = next((p for p in self.pc_list_data if p["id"] == source_id), None)
        target_pc = next((p for p in self.pc_list_data if p["id"] == target_id), None)
        
        if not source_pc or not target_pc:
             self.log_message(f"[FAIL] Clone failed. Source or Target PC not found.")
             return

        def worker():
            self.log_message(f"[TASK] Starting clone from {source_pc['alias']} to {target_pc['alias']}...")
            
            # Use the same standardized command to get installed packages from the source
            source_command = "dpkg --get-selections | awk '{if ($2 == \"install\") print $1}'"
            package_list, _, source_success = self._run_ssh_command_with_output(source_pc, source_command)

            if not source_success:
                self.log_message(f"[FAIL] Clone failed. Could not retrieve package list from SOURCE PC ({source_pc['alias']}).")
                return
            
            packages_to_deploy = " ".join(package_list.splitlines())
            
            self.log_message(f"[INFO] Deploying {len(package_list.splitlines())} packages to TARGET PC ({target_pc['alias']})...")
            
            # This is a full installation of everything installed on the source.
            # Apply DEBIAN_FRONTEND for non-interactive installation
            target_script = (
                f"DEBIAN_FRONTEND=noninteractive apt update && "
                f"DEBIAN_FRONTEND=noninteractive apt install -y {packages_to_deploy}"
            )
            target_command = f"sudo sh -c '{target_script}'" 
            
            target_success, target_status = self._run_ssh_command(target_pc, target_command)
            
            current_time = self._get_current_time_str()
            if target_success:
                new_status = "Cloned OK"
                pending_updates = self._check_pending_updates_count(target_pc)
                self.db_manager.update_status(target_id, new_status, current_time, pending_updates)
                self.log_message(f"[SUCCESS] Clone complete. Target PC ({target_pc['alias']}) set to {new_status}.")
                self.master.after(0, lambda p=target_id, s=new_status, t=current_time, u=pending_updates: self._update_pc_row_data(p, s, t, u))
            else:
                new_status = f"Clone Failed: {target_status}"
                self.db_manager.update_status(target_id, new_status, current_time, 0)
                self.log_message(f"[FAIL] Clone failed on TARGET PC ({target_pc['alias']}): {target_status}")
                self.master.after(0, lambda p=target_id, s=new_status, t=current_time, u=0: self._update_pc_row_data(p, s, t, u))

        threading.Thread(target=worker).start()


# --- Main Entry ---
if __name__ == "__main__":
    db_manager = DBManager()

    root = tk.Tk()

    app = PCManager(root, db_manager)

    root.mainloop()
