#!/usr/bin/env python3
import gi
import warnings
import sys
import sqlite3
import threading
import os
import paramiko
import time
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from datetime import datetime

# --- Warning Suppression ---
warnings.filterwarnings("ignore", category=DeprecationWarning)

# --- GTK Import and Setup ---
try:
    gi.require_version("Gtk", "4.0")
    gi.require_version("Gdk", "4.0")
    from gi.repository import Gtk, GObject, GLib, Gio, Gdk
    GTK_VERSION = 4
except ImportError:
    try:
        gi.require_version("Gtk", "3.0")
        gi.require_version("Gdk", "3.0")
        from gi.repository import Gtk, GObject, GLib, Gio, Gdk
        GTK_VERSION = 3
    except ImportError as e:
        print(f"[FATAL ERROR] Failed to import GTK dependencies: {e}", file=sys.stderr)
        sys.exit(1)

# --- GTK Application Flag Fix ---
if hasattr(Gtk, "ApplicationFlags"):
    APP_FLAGS = Gtk.ApplicationFlags.FLAGS_NONE
elif hasattr(Gio, "ApplicationFlags"):
    APP_FLAGS = Gio.ApplicationFlags.FLAGS_NONE
else:
    APP_FLAGS = 0

# --- Global Config ---
APP_NAME = "Remote Linux Manager"
DB_NAME = "pc_manager.db"
KEY_FILE = ".secret.key"
APP_ID = "com.example.RemoteLinuxManager"
CSS_PROVIDER = None
SSH_CONNECT_TIMEOUT = 10
MONITOR_POLL_INTERVAL_SECONDS = 10


# --- Encryption Utility ---
class EncryptionUtility:
    def __init__(self, key_file=KEY_FILE):
        self.key_file = key_file
        self._ensure_key()
        self.fernet = Fernet(self.key)

    def _ensure_key(self):
        if os.path.exists(self.key_file):
            with open(self.key_file, "rb") as f:
                self.key = f.read()
            print("[INFO] Encryption key loaded.")
        else:
            self.key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                # FIX: Corrected typo from self.write(self.key) to f.write(self.key)
                f.write(self.key)
            print("[INFO] New encryption key generated and saved.")

    def encrypt(self, data):
        return self.fernet.encrypt(data.encode())

    def decrypt(self, token):
        try:
            return self.fernet.decrypt(token).decode()
        except Exception as e:
            print(f"[ERROR] Decryption failed: {e}", file=sys.stderr)
            return None


# --- Database Manager ---
class DBManager:
    def __init__(self, db_name=DB_NAME):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS pcs (
                id INTEGER PRIMARY KEY,
                hostname TEXT NOT NULL,
                username TEXT NOT NULL,
                password_encrypted BLOB NOT NULL,
                alias TEXT,
                status TEXT,
                last_update TEXT,
                pending_updates INTEGER DEFAULT 0
            )
        """
        )
        # --- NEW TABLE FOR SOFTWARE SNAPSHOTS ---
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS software_snapshots (
                id INTEGER PRIMARY KEY,
                pc_id INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                package_list TEXT NOT NULL,
                FOREIGN KEY (pc_id) REFERENCES pcs(id)
            )
        """
        )
        self.conn.commit()
        try:
            self.cursor.execute("SELECT pending_updates FROM pcs LIMIT 1")
        except sqlite3.OperationalError:
            self.cursor.execute("ALTER TABLE pcs ADD COLUMN pending_updates INTEGER DEFAULT 0")
            self.conn.commit()
        print("[INFO] Database table ensured.")

    def get_all_pcs(self):
        self.cursor.execute(
            "SELECT id, hostname, username, password_encrypted, alias, status, last_update, pending_updates FROM pcs ORDER BY alias, hostname"
        )
        return self.cursor.fetchall()

    def add_pc(self, hostname, username, encrypted_password, alias):
        self.cursor.execute(
            "INSERT INTO pcs (hostname, username, password_encrypted, alias, status, last_update, pending_updates) VALUES (?, ?, ?, ?, 'Unknown', 'N/A', 0)",
            (hostname, username, encrypted_password, alias),
        )
        self.conn.commit()
        return self.cursor.lastrowid

    def delete_pc(self, pc_id):
        self.cursor.execute("DELETE FROM pcs WHERE id=?", (pc_id,))
        self.conn.commit()

    def update_status(self, pc_id, status, last_update, pending_updates=0):
        self.cursor.execute(
            "UPDATE pcs SET status=?, last_update=?, pending_updates=? WHERE id=?",
            (status, last_update, pending_updates, pc_id),
        )
        self.conn.commit()

    def update_pc(self, pc_id, hostname, username, encrypted_password, alias):
        """Updates an existing PC's details."""
        self.cursor.execute(
            "UPDATE pcs SET hostname=?, username=?, password_encrypted=?, alias=? WHERE id=?",
            (hostname, username, encrypted_password, alias, pc_id),
        )
        self.conn.commit()
        
    # --- NEW SNAPSHOT METHODS ---
    def save_snapshot(self, pc_id, package_list_data):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute(
            "INSERT INTO software_snapshots (pc_id, timestamp, package_list) VALUES (?, ?, ?)",
            (pc_id, timestamp, package_list_data),
        )
        self.conn.commit()

    def get_latest_snapshot(self, pc_id):
        self.cursor.execute(
            "SELECT package_list FROM software_snapshots WHERE pc_id=? ORDER BY timestamp DESC LIMIT 1",
            (pc_id,),
        )
        result = self.cursor.fetchone()
        return result[0] if result else None


# --- Add PC Dialog Class (Used for both Add and Edit) ---
class AddPCDialog(Gtk.Dialog):
    def __init__(self, parent):
        if GTK_VERSION == 4:
            super().__init__(
                title="Add New PC",
                transient_for=parent,
                modal=True,
                default_width=400,
                default_height=300
            )
        else:
            super().__init__(
                title="Add New PC",
                transient_for=parent,
                modal=True
            )
            self.set_default_size(400, 300)

        # Set up content area layout
        if GTK_VERSION == 4:
            content_area = self.get_content_area()
            content_area.set_orientation(Gtk.Orientation.VERTICAL)
            content_area.set_spacing(10)
        else:
            content_area = self.get_content_area()
            content_area.set_spacing(10)

        content_area.set_margin_top(12)
        content_area.set_margin_bottom(12)
        content_area.set_margin_start(12)
        content_area.set_margin_end(12)

        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)

        fields = [
            ("Alias:", "alias_entry"),
            # --- PREVIOUS MODIFICATION: Hostname or IP Label ---
            ("Hostname or IP:", "hostname_entry"),
            # --- END PREVIOUS MODIFICATION ---
            ("Username:", "username_entry"),
            ("Password:", "password_entry"),
        ]

        # Create fields and entries
        self.entries = {}
        for i, (label_text, entry_key) in enumerate(fields):
            label = Gtk.Label(label=label_text)
            label.set_halign(Gtk.Align.END)
            entry = Gtk.Entry()

            if entry_key == "password_entry":
                entry.set_visibility(False)
                entry.set_placeholder_text("(Leave blank to keep existing password)") # Added placeholder for Edit

            self.entries[entry_key] = entry

            if GTK_VERSION == 4:
                grid.attach(label, 0, i, 1, 1)
                grid.attach(entry, 1, i, 1, 1)
            else:
                grid.attach(label, 0, i, 1, 1)
                grid.attach(entry, 1, i, 1, 1)

        # Append grid to content area
        if GTK_VERSION == 4:
            content_area.append(grid)
            # Add buttons (GTK 4 way)
            self.add_button("_CANCEL", Gtk.ResponseType.CANCEL)
            self.add_button("_ADD", Gtk.ResponseType.OK)
            self.set_default_response(Gtk.ResponseType.OK)
        else:
            # Add buttons (GTK 3 way)
            content_area.pack_start(grid, True, True, 0)
            self.add_buttons(
                "_Cancel", Gtk.ResponseType.CANCEL,
                "_Add", Gtk.ResponseType.OK
            )
            self.set_default_response(Gtk.ResponseType.OK)
            self.show_all()

    def get_data(self):
        """Extracts and cleans data from the input fields."""
        data = {key.replace('_entry', ''): entry.get_text().strip()
                for key, entry in self.entries.items()}
        return data


# --- Deploy Software Dialog Class ---
class DeploySoftwareDialog(Gtk.Dialog):
    def __init__(self, parent):
        if GTK_VERSION == 4:
            super().__init__(
                title="Deploy Software to Selected PCs",
                transient_for=parent,
                modal=True,
                default_width=450,
                default_height=200
            )
        else:
            super().__init__(
                title="Deploy Software to Selected PCs",
                transient_for=parent,
                modal=True
            )
            self.set_default_size(450, 200)

        if GTK_VERSION == 4:
            content_area = self.get_content_area()
            content_area.set_orientation(Gtk.Orientation.VERTICAL)
            content_area.set_spacing(15)
        else:
            content_area = self.get_content_area()
            content_area.set_spacing(15)

        content_area.set_margin_top(12)
        content_area.set_margin_bottom(12)
        content_area.set_margin_start(12)
        content_area.set_margin_end(12)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)

        info_label = Gtk.Label(label="Enter software package names (separated by **space** or **comma**):")
        info_label.set_halign(Gtk.Align.START)
        if GTK_VERSION == 4:
            vbox.append(info_label)
        else:
            vbox.pack_start(info_label, False, False, 0)

        self.software_entry = Gtk.Entry()
        self.software_entry.set_placeholder_text("e.g., htop git vim")
        if GTK_VERSION == 4:
            vbox.append(self.software_entry)
        else:
            vbox.pack_start(self.software_entry, True, True, 0)

        # Add buttons
        if GTK_VERSION == 4:
            content_area.append(vbox)
            self.add_button("_CANCEL", Gtk.ResponseType.CANCEL)
            self.add_button("_DEPLOY", Gtk.ResponseType.OK)
            self.set_default_response(Gtk.ResponseType.OK)
        else:
            content_area.pack_start(vbox, True, True, 0)
            self.add_buttons(
                "_Cancel", Gtk.ResponseType.CANCEL,
                "_Deploy", Gtk.ResponseType.OK
            )
            self.set_default_response(Gtk.ResponseType.OK)
            self.show_all()

    def get_packages(self):
        """Extracts and formats package names for the command."""
        text = self.software_entry.get_text().strip()
        if not text:
            return []

        # Normalize: replace commas with spaces, then split by space, filter empty strings
        packages = text.replace(',', ' ').split()
        return packages


# --- Main Window Class ---
class PCManager(Gtk.ApplicationWindow):
    def __init__(self, app, db_manager):
        super().__init__(application=app)
        self.set_title(APP_NAME)
        # --- COSMETIC CHANGE: Window size to 800x800 ---
        self.set_default_size(800, 800)
        self.db_manager = db_manager
        self.pc_list_data = []
        self.monitoring_pcs = {}

        self.encryption_util = EncryptionUtility()

        self._setup_css()
        self.setup_ui()

    def _setup_css(self):
        global CSS_PROVIDER
        if CSS_PROVIDER is None:
            CSS_PROVIDER = Gtk.CssProvider()
            css = """
                /* Global Font Size Increase */
                * {
                    font-size: 10.5pt;
                }

                window { background-color: #2e3440; }
                headerbar { background-color: #3b4252; }
                label { color: #d8dee9; }

                /* --- Titlebar Button Colors (FIX: Removed !important to stop parser error) --- */
                headerbar button.titlebar.close {
                    /* background-color: #bf616a; <--- REMOVED background-color here to show effect of "not specifying a colour" */
                    color: #eceff4;
                    border-radius: 6px;
                }
                headerbar button.titlebar.close:hover {
                    background-color: #d08770;
                }

                headerbar button.titlebar.minimize,
                headerbar button.titlebar.maximize {
                    background-color: #4c566a;
                    color: #eceff4;
                    border-radius: 6px;
                }
                headerbar button.titlebar.minimize:hover,
                headerbar button.titlebar.maximize:hover {
                    background-color: #5e81ac;
                }
                /* --- END Titlebar Button Colors --- */


                /* --- Base Button Style (Nord Blue: #5e81ac) --- */
                button {
                    background-color: #5e81ac; /* Default Primary Blue */
                    color: white;
                    border-radius: 6px;
                    padding: 8px 15px;
                    margin: 5px;
                    border: 1px solid transparent;
                    transition: all 0.2s; /* Smooth transition for hover effects */
                }

                /* --- Hover/Focus State (Making selection obvious) --- */
                button:hover {
                    background-color: #81a1c1; /* Lighter shade on hover */
                    box-shadow: 0 0 0 3px #81a1c1; /* Glow effect */
                    border-color: #eceff4; /* White border */
                }
                button:active, button:focus {
                    background-color: #88c0d0; /* Even Lighter Blue/Cyan on press/focus */
                    border: 2px solid white;
                    box-shadow: none;
                }

                /* --- Custom Button Styles --- */

                /* Red/Destructive for Shutdown and Reboot */
                .destructive-button {
                    background-color: #bf616a; /* Nord Red */
                }
                .destructive-button:hover {
                    background-color: #d08770; /* Nord Orange-ish, slightly softer */
                    box-shadow: 0 0 0 3px #bf616a;
                    border-color: #eceff4;
                }
                .destructive-button:active, .destructive-button:focus {
                    background-color: #e59098;
                    border: 2px solid white;
                }

                /* Green/Success for Check Status */
                .success-button {
                    background-color: #a3be8c; /* Nord Green */
                    color: #2e3440; /* Dark text for contrast */
                }
                .success-button:hover {
                    background-color: #b4c8a2;
                    box-shadow: 0 0 0 3px #a3be8c;
                    border-color: #2e3440;
                }
                .success-button:active, .success-button:focus {
                    background-color: #c0d8b2;
                    border: 2px solid #2e3440;
                }
                
                /* --- NEW COLOR GROUP: Teal/Cyan for Deployment/Snapshot/Clone --- */
                .deployment-button {
                    background-color: #88c0d0; /* Nord Cyan */
                    color: #2e3440; /* Dark text for contrast and readability */
                }
                .deployment-button:hover {
                    background-color: #9cd4e3;
                    box-shadow: 0 0 0 3px #88c0d0;
                    border-color: #2e3440;
                }
                .deployment-button:active, .deployment-button:focus {
                    background-color: #b0e3f0;
                    border: 2px solid #2e3440;
                }

                /* Yellow/Warning for Delete PC and Revert Snapshot */
                .warning-button {
                    background-color: #ebcb8b; /* Nord Yellow/Orange */
                    color: #2e3440; /* Dark text for contrast */
                }
                .warning-button:hover {
                    background-color: #f0d89c;
                    box-shadow: 0 0 0 3px #ebcb8b;
                    border-color: #2e3440;
                }
                .warning-button:active, button.warning-button:focus {
                    background-color: #f4e5b6;
                    border: 2px solid #2e3440;
                }

                /* --- TreeView Header Styling (Applies to ALL column TITLES) --- */
                treeview header button {
                    background-color: #4c566a; /* Soft blue-gray for column header button background */
                    color: #eceff4; /* Lighter text color */
                    border-radius: 0;
                    border-bottom: 2px solid #3b4252; /* Darker bottom border for separation */
                    padding: 8px 5px;
                    font-weight: bold;
                }
                treeview header button:hover {
                    background-color: #5e81ac; /* Slightly lighter blue on hover */
                    box-shadow: none;
                }
            """
            try:
                CSS_PROVIDER.load_from_data(css.encode())
                if GTK_VERSION == 4:
                    Gtk.StyleContext.add_provider_for_display(
                        Gdk.Display.get_default(),
                        CSS_PROVIDER,
                        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
                    )
                else:
                    screen = Gdk.Screen.get_default()
                    Gtk.StyleContext.add_provider_for_screen(
                        screen,
                        CSS_PROVIDER,
                        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
                    )
            except Exception as e:
                print(f"[ERROR] Could not load CSS: {e}")

    # --- UI Setup ---
    def setup_ui(self):
        # Enforce minimum size (GTK 3 and 4 compatible)
        # --- COSMETIC CHANGE: Set minimum size to 800x800 ---
        self.set_size_request(800, 800)

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        main_box.set_margin_top(12)
        main_box.set_margin_bottom(12)
        main_box.set_margin_start(12)
        main_box.set_margin_end(12)

        header_bar = Gtk.HeaderBar()
        header_bar.set_title_widget(Gtk.Label(label=APP_NAME, halign=Gtk.Align.CENTER))
        header_bar.set_show_title_buttons(True)
        self.set_titlebar(header_bar)

        self.pc_list_store = Gtk.ListStore(int, str, str, object, str, str, str, int, int)
        self.pc_list_view = Gtk.TreeView(model=self.pc_list_store)

        # Define columns and their desired width properties (preserving width changes)
        # Format: (Title, Model Index, Min Width, Fixed Width)
        column_configs = [
            ("Alias", 4, 200, None),         # Wider alias column
            ("Status", 5, 100, None),        # Decent width for status
            ("Pending Updates", 8, 80, None), # Small enough
            ("Last Update", 6, None, 160),   # Fixed width to reduce it
        ]

        for title, col_idx, min_width, fixed_width in column_configs:
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=col_idx)

            if fixed_width:
                # Use fixed width for the timestamp column to restrict its size.
                column.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
                column.set_fixed_width(fixed_width)
            elif min_width:
                # Use grow-only sizing with a minimum width for Alias and Status.
                column.set_sizing(Gtk.TreeViewColumnSizing.GROW_ONLY)
                column.set_min_width(min_width)

            self.pc_list_view.append_column(column)

        self.selection = self.pc_list_view.get_selection()
        self.selection.set_mode(Gtk.SelectionMode.MULTIPLE) # RESTORED MULTI-SELECTION
        self.selection.connect("changed", self.on_selection_changed)
        self.selected_pc_id = None

        scrolled = Gtk.ScrolledWindow()
        if GTK_VERSION == 4:
            scrolled.set_child(self.pc_list_view)
        else:
            scrolled.add(self.pc_list_view)
        scrolled.set_vexpand(True)

        # --- COSMETIC CHANGE: Two Rows of Buttons ---
        button_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        top_button_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        bottom_button_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)


        # Define the buttons, their CSS class, and the row they belong to
        button_map = {
            # Row 1: PC Management & Status (Blue/Green/Warning)
            "Add PC": {"handler": self.on_add_pc_clicked, "css_class": None, "row": 1},
            "Edit PC": {"handler": self.on_edit_pc_clicked, "css_class": None, "row": 1},
            "Check Status": {"handler": self.on_refresh_clicked, "css_class": "success-button", "row": 1},
            "Delete PC": {"handler": lambda w: self._show_confirmation_dialog("delete", "Delete"), "css_class": "warning-button", "row": 1},
            
            # Row 2: Operation & Lifecycle (Teal/Red/Warning)
            "Run Update": {"handler": lambda w: self.on_action_clicked(w, "update"), "css_class": "deployment-button", "row": 2},
            "Deploy Software": {"handler": self.on_deploy_software_clicked, "css_class": "deployment-button", "row": 2},
            "Clone PC": {"handler": lambda w: self._show_confirmation_dialog("clone", "Clone"), "css_class": "deployment-button", "row": 2},
            "Create Snapshot": {"handler": lambda w: self._show_confirmation_dialog("create_snapshot", "Create Snapshot"), "css_class": "deployment-button", "row": 2}, 
            "Revert to snapshot": {"handler": lambda w: self._show_confirmation_dialog("revert", "Revert"), "css_class": "warning-button", "row": 2},
            "Reboot PC": {"handler": lambda w: self._show_confirmation_dialog("reboot", "Reboot"), "css_class": "destructive-button", "row": 2},
            "Shutdown PC": {"handler": lambda w: self._show_confirmation_dialog("shutdown", "Shutdown"), "css_class": "destructive-button", "row": 2},
        }

        # Define the explicit order for buttons
        button_order = [
            # Row 1 Order
            "Add PC", "Edit PC", "Delete PC", "Check Status",
            # Row 2 Order
            "Run Update", "Deploy Software", "Clone PC", "Create Snapshot", "Revert to snapshot", "Reboot PC", "Shutdown PC"
        ]

        for label in button_order:
            b_info = button_map.get(label)
            handler = b_info["handler"]
            css_class = b_info["css_class"]
            row_num = b_info["row"]

            b = Gtk.Button(label=label)
            b.connect("clicked", handler)

            # Apply CSS Class
            if css_class:
                if GTK_VERSION == 4:
                    b.add_css_class(css_class)
                else:
                    if hasattr(b, 'get_style_context'):
                         b.get_style_context().add_class(css_class)

            # Assign to the correct horizontal box
            target_box = top_button_row if row_num == 1 else bottom_button_row

            if GTK_VERSION == 4:
                target_box.append(b)
            else:
                target_box.pack_start(b, False, False, 0)
        
        # Combine the two rows into the main vertical button box
        if GTK_VERSION == 4:
            button_vbox.append(top_button_row)
            button_vbox.append(bottom_button_row)
        else:
            button_vbox.pack_start(top_button_row, False, False, 0)
            button_vbox.pack_start(bottom_button_row, False, False, 0)

        # Log View Setup
        log_buffer = Gtk.TextBuffer()
        self.log_view = Gtk.TextView(buffer=log_buffer, editable=False)
        log_scrolled = Gtk.ScrolledWindow()
        if GTK_VERSION == 4:
            log_scrolled.set_child(self.log_view)
        else:
            log_scrolled.add(self.log_view)

        # Set fixed size for log view to fill bottom half of the window
        log_scrolled.set_size_request(-1, 300) # Keep this or adjust based on 800x800

        if GTK_VERSION == 4:
            main_box.append(scrolled)
            # Use the new vertical button box
            main_box.append(button_vbox)
            main_box.append(log_scrolled)
            self.set_child(main_box)
        else:
            main_box.pack_start(scrolled, True, True, 0)
            # Use the new vertical button box
            main_box.pack_start(button_vbox, False, False, 0)
            main_box.pack_start(log_scrolled, False, False, 0)
            self.add(main_box)

        self.load_pc_data()
        self.log_message(f"[{APP_NAME}] Initialized with GTK {GTK_VERSION}")
        self.on_refresh_clicked(None)

    # --- Logging / Data management (Rest of class methods unchanged) ---
    def log_message(self, message):
        def append():
            buf = self.log_view.get_buffer()
            end = buf.get_end_iter()
            buf.insert(end, f"{message}\n")
            mark = buf.create_mark("end", buf.get_end_iter(), False)
            self.log_view.scroll_to_mark(mark, 0, True, 0, 0)
            buf.delete_mark(mark)
        GLib.idle_add(append)

    def _get_current_time_str(self):
        """Helper function to format current time."""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def load_pc_data(self):
        self.pc_list_data.clear()
        self.pc_list_store.clear()
        for idx, row in enumerate(self.db_manager.get_all_pcs()):
            if len(row) == 7:
                pc_id, host, user, enc, alias, status, last = row
                pending = 0
            else:
                pc_id, host, user, enc, alias, status, last, pending = row
            self.pc_list_data.append(
                dict(id=pc_id, hostname=host, username=user, password_encrypted=enc,
                     alias=alias, status=status, last_update=last,
                     pending_updates=pending, index=idx)
            )
            # Row structure: int, str, str, object, str, str, str, int, int
            self.pc_list_store.append([pc_id, host, user, enc, alias, status, last, idx, pending])

    def on_selection_changed(self, sel):
        model, path_list = sel.get_selected_rows()

        if path_list:
            first_path = path_list[0]
            it = model.get_iter(first_path)
            self.selected_pc_id = model.get_value(it, 0)
        else:
            self.selected_pc_id = None

    # --- Confirmation Dialog (MODIFIED for Create/Clone/Revert) ---
    def _show_confirmation_dialog(self, action, label):
        # Check for multiple selection
        model, path_list = self.selection.get_selected_rows()
        target_ids = [model.get_value(model.get_iter(path), 0) for path in path_list]

        if not target_ids:
            self.log_message(f"[ERROR] Select a PC first to {action.replace('_', ' ').lower()}.")
            return

        # Initialize variables
        dialog_title = f"Confirm {label}"
        dialog_type = Gtk.MessageType.WARNING
        sec = ""
        msg = ""

        if action == "create_snapshot":
            # --- CREATE SNAPSHOT LOGIC ---
            if len(target_ids) != 1:
                self.log_message(f"[ERROR] Snapshot creation requires selecting exactly ONE PC.")
                return

            pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            alias = pc["alias"] if pc else f"ID {target_ids[0]}"
            pc_name_styled = f'<span foreground="#5e81ac" weight="bold" size="16000">{alias.upper()}</span>' # Blue for a standard action

            # Message for Create Snapshot
            msg = f"Confirm new snapshot **CREATION** for {pc_name_styled}?"
            sec = "A snapshot of the installed software list will be saved to the database. This is used for reverting the PC's software state later."
            dialog_title = "Confirm Software Snapshot Creation"
            dialog_type = Gtk.MessageType.INFO # Use INFO type for a non-destructive, standard action

        elif action == "clone":
            # --- CLONING LOGIC (Addresses the user's second request) ---
            if len(target_ids) != 2:
                self.log_message(f"[ERROR] Cloning requires selecting exactly TWO PCs: the Source and the Target.")
                return

            # Assume first selected is SOURCE, second is TARGET (based on selection order)
            source_pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), {"alias": f"ID {target_ids[0]}"})
            target_pc = next((p for p in self.pc_list_data if p["id"] == target_ids[1]), {"alias": f"ID {target_ids[1]}"})

            # Style the PC Names with different colours for clarity
            source_styled = f'<span foreground="#a3be8c" weight="bold" size="16000">{source_pc["alias"].upper()}</span>' # Green for Source
            target_styled = f'<span foreground="#bf616a" weight="bold" size="16000">{target_pc["alias"].upper()}</span>' # Red for Target (Destructive)

            # Message Construction
            msg = f"Are you sure you want to clone from PC {source_styled} to PC {target_styled}?"
            sec = "⚠️ **WARNING**: This will overwrite ALL data on the TARGET PC and cannot be undone."
            dialog_title = "Confirm PC Clone & Overwrite"
            dialog_type = Gtk.MessageType.ERROR # Use ERROR type for maximum warning

        elif action == "revert":
            # --- REVERT LOGIC (Addresses the user's first request) ---
            if len(target_ids) > 1:
                self.log_message(f"[ERROR] Reverting a snapshot can only be performed on a single PC at a time.")
                return

            pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            alias = pc["alias"] if pc else f"ID {target_ids[0]}"
            pc_name_styled = f'<span foreground="#ebcb8b" weight="bold" size="16000">{alias.upper()}</span>' # Yellow/Orange for Warning

            # Message for Revert
            msg = f"Confirm **REVERT** to snapshot for {pc_name_styled}?"
            # Secondary text shows what will be removed
            sec = "⚠️ **WARNING**: This action will remove all software installed since the last snapshot. This cannot be undone."
            dialog_title = "Confirm Software Snapshot Revert"

        else:
            # --- EXISTING ACTIONS (delete, reboot, shutdown) ---

            # Determine alias for display
            if len(target_ids) > 1:
                alias = f"{len(target_ids)} PC(s)"
            else:
                pc = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
                alias = pc["alias"] if pc else f"ID {target_ids[0]}"

            # --- APPLY CUSTOM STYLING (PC Alias is now bigger) ---
            pc_name_styled = f'<span foreground="#88c0d0" weight="bold" size="16000">{alias.upper()}</span>'

            # Operation Name: Lowercase
            op_name = label.lower()

            # Message Construction
            if len(target_ids) > 1 and action != "delete":
                # Multi-PC message
                msg = f"Are you sure you want to {op_name} {pc_name_styled}?"
                # Custom secondary text for destructive multi-PC actions
                if action == "shutdown":
                    sec = "This will power off all selected PCs in 1 minute."
                elif action == "reboot":
                    sec = "This will restart all selected PCs in 1 minute."

            else:
                # Single-PC message
                msg_map = {
                    "delete": (f"Are you sure you want to {op_name} {pc_name_styled}?", "This removes it from the list only."),
                    "shutdown": (f"Are you sure you want to {op_name} {pc_name_styled}?", "It will power off in 1 minute."),
                    "reboot": (f"Are you sure you want to {op_name} {pc_name_styled}?", "It will restart in 1 minute.")
                }
                msg_tuple = msg_map.get(action, (f"Confirm {op_name} on {pc_name_styled}?", ""))
                msg = msg_tuple[0]
                sec = msg_tuple[1]

        # Create dialog
        dialog = Gtk.MessageDialog(
            transient_for=self, modal=True,
            buttons=Gtk.ButtonsType.YES_NO,
            message_type=dialog_type)

        dialog.set_title(dialog_title)


        # --- FIX: Explicitly set Pango Markup on the internal label ---
        main_label = None
        try:
            if GTK_VERSION == 4:
                # GTK 4 reliable method: Get the message area (a box) and find the first child (the label)
                main_label = dialog.get_message_area().get_first_child()
            else:
                # GTK 3 reliable method: Iterate through the message container to find the Gtk.Label
                primary_box = dialog.get_content_area().get_children()[0]
                main_label = next((c for c in primary_box.get_children() if isinstance(c, Gtk.Label)), None)

            if main_label and isinstance(main_label, Gtk.Label):
                main_label.set_markup(msg)
            else:
                # Fallback for unexpected internal structure
                dialog.set_text(msg)
                self.log_message("[WARN] Pango markup failed. Could not find internal Gtk.Label.")

        except Exception as e:
            dialog.set_text(msg)
            self.log_message(f"[WARN] Pango markup failed due to error: {e}")

        # --- Secondary Text (now explicitly supports Pango for the WARNING text) ---
        if sec:
            if GTK_VERSION == 4:
                if hasattr(dialog, 'set_secondary_text'):
                    dialog.set_secondary_text(sec)
                elif hasattr(dialog, 'secondary_label'):
                    # Attempt to set markup if secondary_label is exposed
                    dialog.secondary_label.set_markup(sec) 
                else:
                    pass
            else:
                # GTK 3: Use format_secondary_text, but we also try to find the label to set markup
                secondary_label = None
                primary_box = dialog.get_content_area().get_children()[0]
                if len(primary_box.get_children()) > 1 and isinstance(primary_box.get_children()[1], Gtk.Label):
                    secondary_label = primary_box.get_children()[1]
                
                if secondary_label:
                    secondary_label.set_markup(sec)
                else:
                    dialog.format_secondary_text(sec)


        dialog.target_ids = target_ids

        if GTK_VERSION == 4:
            dialog.connect("response", lambda d, r: (self._on_confirmation_dialog_response(r, action, d.target_ids), d.destroy()))
            dialog.present()
        else:
            dialog.show_all()
            r = dialog.run()
            self._on_confirmation_dialog_response(r, action, dialog.target_ids)
            dialog.destroy()


    def _on_confirmation_dialog_response(self, resp, action, target_ids):
        if resp == Gtk.ResponseType.YES:
            if action == "delete":
                self.on_delete_pc_clicked(None, target_ids)
            elif action == "clone":
                self.run_clone_action(target_ids)
            elif action == "revert":
                self.run_revert_action(target_ids)
            elif action == "create_snapshot":
                self.run_create_snapshot_action(target_ids)
            else:
                pc_list = [p for p in self.pc_list_data if p["id"] in target_ids]
                self.run_mass_action_thread(pc_list, action)
        else:
            self.log_message(f"[INFO] {action.replace('_', ' ').capitalize()} cancelled.")
            
    # --- New SSH Helper to get Command Output (used by snapshot/revert) ---
    def _run_ssh_command_with_output(self, pc_info, command):
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]
        connect_host = host
        if '.' not in host:
            connect_host = f"{host}.local"
        
        password = self.encryption_util.decrypt(pc_info["password_encrypted"])

        if not isinstance(password, str):
            self.log_message(f"[FATAL] Auth failed for '{alias}'. Invalid password key.")
            return "", "Authentication Error", False

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh.connect(connect_host, username=user, password=password, timeout=SSH_CONNECT_TIMEOUT)
            
            # Use 'sudo -S' to run the command and pipe password if needed
            if 'sudo' in command.lower():
                 stdin, stdout, stderr = ssh.exec_command(command, get_pty=False)
                 stdin.write(password + '\n')
                 stdin.flush()
            else:
                 stdin, stdout, stderr = ssh.exec_command(command)

            output = stdout.read().decode().strip()
            error = stderr.read().decode().strip()

            if error and not output: # If there's an error and no output (common for failure)
                 return "", error, False
            if "REVERT_FAILED" in output or "DEPLOYMENT_FAILED" in output:
                 return output, error, False

            return output, error, True
        
        except paramiko.AuthenticationException:
            return "", "Authentication Failed", False
        except paramiko.SSHException as e:
            return "", f"SSH Error: {e}", False
        except TimeoutError:
            return "", "Connection Timeout", False
        except Exception as e:
            return "", f"Unknown Error: {e}", False
        finally:
            if 'ssh' in locals() and ssh:
                ssh.close()
                
    # --- Snapshot Creation Worker (Non-blocking logic) ---
    def _worker_create_snapshot(self, pc_info):
        alias = pc_info["alias"]
        pc_id = pc_info["id"]

        GLib.idle_add(lambda: self.log_message(f"[START] **SNAPSHOT** creation started for '{alias}'."))

        # Command to get a clean list of installed package names (name only)
        command = "dpkg-query -W -f='${Package}\n' | sort"
        
        # 1. Fetch the installed software list
        package_list_data, error, success = self._run_ssh_command_with_output(pc_info, command)

        if success and package_list_data:
            # 2. Save the list to the new database table
            GLib.idle_add(lambda: self.db_manager.save_snapshot(pc_id, package_list_data))
            
            package_count = len(package_list_data.splitlines())
            GLib.idle_add(lambda: self.log_message(f"[COMPLETE] **SNAPSHOT** created successfully for '{alias}'. {package_count} packages recorded."))
        else:
            GLib.idle_add(lambda: self.log_message(f"[ERROR] **SNAPSHOT** failed for '{alias}'. Reason: {error}"))

    # --- Snapshot Revert Worker (Non-blocking logic) ---
    def _worker_revert_snapshot(self, pc_info):
        alias = pc_info["alias"]
        pc_id = pc_info["id"]

        GLib.idle_add(lambda: self.log_message(f"[START] **REVERT** to snapshot started for '{alias}'."))

        # 1. Fetch the stored snapshot list from the DB
        snapshot_data_str = self.db_manager.get_latest_snapshot(pc_id)

        if not snapshot_data_str:
            GLib.idle_add(lambda: self.log_message(f"[ERROR] **REVERT** failed: No snapshot found in database for '{alias}'."))
            return

        # 2. Fetch the current installed list from the PC
        command_current = "dpkg-query -W -f='${Package}\n' | sort"
        current_data_str, error_current, success_current = self._run_ssh_command_with_output(pc_info, command_current)

        if not success_current or not current_data_str:
            GLib.idle_add(lambda: self.log_message(f"[ERROR] **REVERT** failed: Could not retrieve current software list from '{alias}'. Reason: {error_current}"))
            return

        # 3. Compare the lists (using Python sets for efficient comparison)
        snapshot_packages = set(snapshot_data_str.splitlines())
        current_packages = set(current_data_str.splitlines())

        # Packages to remove: currently installed packages NOT found in the snapshot list
        packages_to_remove = current_packages - snapshot_packages

        if not packages_to_remove:
            GLib.idle_add(lambda: self.log_message(f"[COMPLETE] **REVERT** finished for '{alias}'. PC is already in the snapshot state. No packages removed."))
            return

        package_list_str = ' '.join(packages_to_remove)
        removal_count = len(packages_to_remove)

        GLib.idle_add(lambda: self.log_message(f"[WARN] **REVERT** found {removal_count} package(s) to remove from '{alias}'. Executing purge..."))

        # 4. Construct and execute the removal command
        removal_command = f"sudo -S sh -c 'DEBIAN_FRONTEND=noninteractive apt-get purge -y {package_list_str} < /dev/null && echo \"REVERT_SUCCESSFUL\" || echo \"REVERT_FAILED\"'"

        output, error, success = self._run_ssh_command_with_output(pc_info, removal_command)
        
        if success:
            GLib.idle_add(lambda: self.log_message(f"[COMPLETE] **REVERT** successfully removed {removal_count} packages from '{alias}'. State restored."))
            # Trigger a status check to reflect changes
            GLib.idle_add(lambda: self._check_pc_status_thread(pc_info))
        else:
            GLib.idle_add(lambda: self.log_message(f"[ERROR] **REVERT** FAILED to remove packages on '{alias}'. Command output: {output}, Error: {error}"))

    # --- New Placeholder Action Handlers (now launching threads) ---
    def run_create_snapshot_action(self, target_ids):
        """Launches a thread to collect current packages and save the snapshot."""
        if len(target_ids) == 1:
            pc_info = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            if pc_info:
                thread = threading.Thread(target=self._worker_create_snapshot, args=(pc_info,), daemon=True)
                thread.start()
            else:
                 self.log_message(f"[ERROR] Snapshot creation failed: PC data not found.")
        else:
            self.log_message(f"[ERROR] Create Snapshot action failed: Expected 1 PC, got {len(target_ids)}.")


    def run_clone_action(self, target_ids):
        """Placeholder for the cloning command logic."""
        if len(target_ids) == 2:
            source_id, target_id = target_ids
            source_pc = next((p for p in self.pc_list_data if p["id"] == source_id), None)
            target_pc = next((p for p in self.pc_list_data if p["id"] == target_id), None)
            source_alias = source_pc["alias"] if source_pc else f"ID {source_id}"
            target_alias = target_pc["alias"] if target_pc else f"ID {target_id}"

            self.log_message(f"[INFO] Initiating CLONE from '{source_alias}' to '{target_alias}'. (Action logic not yet implemented)")
        else:
             self.log_message(f"[ERROR] Clone action failed: Expected 2 PCs, got {len(target_ids)}.")

    def run_revert_action(self, target_ids):
        """Launches a thread to compare packages and execute apt-get purge."""
        if len(target_ids) == 1:
            pc_info = next((p for p in self.pc_list_data if p["id"] == target_ids[0]), None)
            if pc_info:
                thread = threading.Thread(target=self._worker_revert_snapshot, args=(pc_info,), daemon=True)
                thread.start()
            else:
                 self.log_message(f"[ERROR] Revert action failed: PC data not found.")
        else:
            self.log_message(f"[ERROR] Revert action failed: Expected 1 PC, got {len(target_ids)}.")

    # --- Status Check & Command Executor (Restored multi-action logic) ---

    def _check_is_reachable(self, host, user, password):
        """Helper to perform a quick SSH connection check."""

        # --- START MODIFICATION FOR .LOCAL RESOLUTION ---
        connect_host = host
        if '.' not in host:
            connect_host = f"{host}.local"
        # --- END MODIFICATION ---

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            # Short timeout (2s) for a quick check.
            ssh.connect(connect_host, username=user, password=password, timeout=2, auth_timeout=2)
            ssh.close()
            return True
        except Exception:
            return False

    def _check_pc_status_thread(self, pc_info):
        """
        Attempts to connect and check for updates by running 'apt update'
        without sudo, followed by counting upgradable packages, using ';' for robustness.
        """
        pc_id = pc_info["id"]
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]
        status = "Offline"
        updates = 0
        last_update = "N/A"

        # --- START MODIFICATION FOR .LOCAL RESOLUTION ---
        connect_host = host
        if '.' not in host:
            connect_host = f"{host}.local"
        # --- END MODIFICATION ---

        password = self.encryption_util.decrypt(pc_info["password_encrypted"])
        if not isinstance(password, str):
            status = "Auth Error"
            self.log_message(f"[FATAL] Status check failed for '{alias}': Invalid/Corrupt password key.")
            GLib.idle_add(lambda: self.db_manager.update_status(pc_id, status, self._get_current_time_str()))
            GLib.idle_add(self.load_pc_data)
            return

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            self.log_message(f"[INFO] Checking status and updates for '{alias}' ({host} -> {connect_host})...")
            # Connect
            ssh.connect(connect_host, username=user, password=password, timeout=5)
            status = "Online"

            # Fix update check failure by using '|| true'
            # Command uses ';' and '|| true' for robustness against apt update warnings (like exit code 100)
            command = "apt update > /dev/null 2>&1 || true; apt list --upgradable 2>/dev/null | grep -c '/'"

            stdin, stdout, stderr = ssh.exec_command(command)
            output = stdout.read().decode().strip()

            try:
                updates = int(output)
                self.log_message(f"[SUCCESS] '{alias}' is Online. {updates} updates pending.")
            except ValueError:
                self.log_message(f"[WARN] '{alias}' is Online. Update count unavailable (Error in output parsing or apt check failed).")
                updates = 0

            last_update = self._get_current_time_str()

        except paramiko.AuthenticationException:
            status = "Auth Error"
            self.log_message(f"[ERROR] Authentication failed for '{alias}'. Check credentials.")
        except paramiko.SSHException as e:
            status = "SSH Error"
            self.log_message(f"[ERROR] SSH error for '{alias}': {e}")
        except TimeoutError:
            status = "Timeout"
            self.log_message(f"[ERROR] Connection to '{alias}' timed out.")
        except Exception as e:
            status = "Unknown Error"
            # Print the host that was attempted in the error message
            self.log_message(f"[FATAL] Error checking '{alias}' ({connect_host}): {e}")
        finally:
            if 'ssh' in locals() and ssh:
                ssh.close()

            # Update DB and GUI from the main thread
            GLib.idle_add(lambda: self.db_manager.update_status(pc_id, status, last_update, updates))
            GLib.idle_add(self.load_pc_data)

    def _monitoring_thread_loop(self, pc_info, action_type):
        """Dedicated thread to monitor PC status after shutdown/reboot command."""
        pc_id = pc_info["id"]
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]

        password = self.encryption_util.decrypt(pc_info["password_encrypted"])
        if not isinstance(password, str):
            self.log_message(f"[MONITOR] Auth failed during polling for '{alias}'. Stopping.")
            # FIX: Ensure dictionary modification is handled by the main thread (GTK)
            GLib.idle_add(lambda: self.monitoring_pcs.pop(pc_id, None))
            return

        is_offline = False

        # --- FIX: Stabilize thread environment ---
        # Add a short initial sleep to ensure the main thread has completed
        # setting up the thread and dictionary entry without race conditions.
        time.sleep(1)
        # ----------------------------------------

        while pc_id in self.monitoring_pcs:
            try:
                # The first check runs immediately upon thread start. Subsequent checks run after the sleep at the end.
                is_reachable = self._check_is_reachable(host, user, password)
                last_update = self._get_current_time_str()
                stop_monitoring = False
                status = None

                if action_type == "reboot":
                    # 1. PC is back online (reachable) and was previously down (is_offline=True)
                    if is_reachable and is_offline:
                        status = "Online"
                        self.log_message(f"[MONITOR] '{alias}' REBOOT cycle **COMPLETE**. Status is now Online. Monitoring stopped.")
                        stop_monitoring = True
                    # 2. PC has gone down (not reachable) and was not previously down (is_offline=False)
                    elif not is_reachable and not is_offline:
                        is_offline = True
                        status = "Rebooting (Offline)"
                        self.log_message(f"[MONITOR] '{alias}' is currently **DOWN** during reboot cycle. Continuing monitoring...")
                    # 3. PC is still up or just started reboot (Stage 1)
                    elif is_reachable and not is_offline:
                        self.log_message(f"[MONITOR] '{alias}' still responsive (Stage 1). Waiting...")
                        status = "Rebooting..."

                elif action_type == "shutdown":
                    # 1. PC has gone offline (not reachable)
                    if not is_reachable:
                        status = "Offline"
                        self.log_message(f"[MONITOR] '{alias}' status confirmed as **OFFLINE**. Monitoring stopped.")
                        stop_monitoring = True
                    # 2. PC is still up
                    else:
                        self.log_message(f"[MONITOR] '{alias}' still responsive during SHUTDOWN cycle. Waiting...")
                        status = "Shutting Down..."

                if status:
                    # Update DB and GUI from the main thread
                    GLib.idle_add(lambda: self.db_manager.update_status(pc_id, status, last_update, 0))
                    GLib.idle_add(self.load_pc_data)

                if stop_monitoring:
                    # Thread is stopping itself. Use GLib.idle_add for safety.
                    GLib.idle_add(lambda: self.monitoring_pcs.pop(pc_id, None))
                    break

                # Only sleep if the monitoring is not stopping.
                time.sleep(MONITOR_POLL_INTERVAL_SECONDS)

            except Exception as e:
                # Catch any unexpected errors (e.g., in _check_is_reachable or GLib updates) to prevent thread crash
                self.log_message(f"[MONITOR-ERROR] Unhandled error during polling for '{alias}': {e}. Retrying in {MONITOR_POLL_INTERVAL_SECONDS}s.")
                # Always sleep here to prevent a runaway loop if the error is persistent and immediate
                time.sleep(MONITOR_POLL_INTERVAL_SECONDS)
                # Loop will continue to the next iteration

        self.log_message(f"[MONITOR] Thread for '{alias}' terminated.")

    def _run_ssh_command(self, pc_info, command, action_type):
        """
        Connects via SSH, executes a command, and pipes the user password
        to the remote sudo prompt using the -S flag for security.
        """
        host = pc_info["hostname"]
        user = pc_info["username"]
        alias = pc_info["alias"]
        pc_id = pc_info["id"]

        # --- START MODIFICATION FOR .LOCAL RESOLUTION ---
        connect_host = host
        if '.' not in host:
            connect_host = f"{host}.local"
        # --- END MODIFICATION ---

        password = self.encryption_util.decrypt(pc_info["password_encrypted"])
        if not isinstance(password, str):
            self.log_message(f"[FATAL] Failed to decrypt password for '{alias}'. Password is invalid or key is corrupt.")
            return

        self.log_message(f"[INFO] Connecting to {alias} ({host} -> {connect_host}) to run '{action_type}'...")

        # Stop any existing monitoring thread for this PC before running a new action
        if pc_id in self.monitoring_pcs:
             self.monitoring_pcs.pop(pc_id, None)
             self.log_message(f"[INFO] Existing monitor stopped for '{alias}'.")

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh.connect(connect_host, username=user, password=password, timeout=SSH_CONNECT_TIMEOUT)

            # --- Non-Blocking/Background Commands (REBOOT, SHUTDOWN) ---
            if action_type in ["reboot", "shutdown"]:
                # Use exec_command and pipe password
                self.log_message(f"[INFO] Running non-blocking command on '{alias}' (expecting connection drop).")
                # Using 'sudo -S' is crucial here for securely passing the password
                stdin, stdout, stderr = ssh.exec_command(command, get_pty=False)

                # Pipe password to stdin
                stdin.write(password + '\n')
                stdin.flush()

                # Give the remote command a moment to start before the connection breaks
                time.sleep(1)

                self.log_message(f"[SUCCESS] Action '{action_type.upper()}' on '{alias}' **INITIATED**.")

                status_text = "Rebooting..." if action_type == "reboot" else "Shutting Down..."
                GLib.idle_add(lambda: self.db_manager.update_status(pc_id, status_text, self._get_current_time_str()))
                GLib.idle_add(self.load_pc_data)

                monitor_thread = threading.Thread(
                    target=self._monitoring_thread_loop,
                    args=(pc_info, action_type),
                    daemon=True
                )
                monitor_thread.start()
                self.monitoring_pcs[pc_id] = monitor_thread
                self.log_message(f"[MONITOR] Started {MONITOR_POLL_INTERVAL_SECONDS}s polling for '{alias}'.")

                # Exit the try block immediately for non-blocking commands
                return

            # --- Blocking Commands (UPDATE, DEPLOY) ---
            # Use sudo -S to pipe password for interactive commands
            stdin, stdout, stderr = ssh.exec_command(command)

            # Write the password to the command's stdin
            self.log_message(f"[INFO] Piped password for sudo to '{alias}'.")
            stdin.write(password + '\n')
            stdin.flush()

            # Read all output
            output = stdout.read().decode().strip()
            error = stderr.read().decode().strip()

            if error:
                self.log_message(f"[WARN] '{alias}' command execution reported errors. Output: {error}")

            if output:
                if action_type == "update":
                    self.log_message(f"[INFO] '{alias}' UPDATE output (partial):\n{output[:500]}...")
                elif action_type == "deploy":
                    if "DEPLOYMENT_SUCCESSFUL" in output:
                        self.log_message(f"[INFO] '{alias}' DEPLOYMENT status: **SUCCESSFUL** ✅. Packages installed or already present.")
                    elif "DEPLOYMENT_FAILED" in output:
                        self.log_message(f"[ERROR] '{alias}' DEPLOYMENT status: **FAILED** ❌. Check package names or PC status.")
                    else:
                         self.log_message(f"[INFO] '{alias}' DEPLOYMENT output (Full output not shown): Installation initiated.")
                else:
                    self.log_message(f"[DEBUG] '{alias}' command output: {output}")

            self.log_message(f"[SUCCESS] Action '{action_type.upper()}' on '{alias}' **COMPLETED**.")

            # After a successful update or deployment, refresh the status check
            if action_type in ["update", "deploy"]:
                self.log_message(f"[INFO] Running final status check for '{alias}' to refresh update count.")
                self._check_pc_status_thread(pc_info)

        except paramiko.AuthenticationException:
            self.log_message(f"[ERROR] Authentication failed for '{alias}'. Check username/password.")
        except paramiko.SSHException as e:
            self.log_message(f"[ERROR] SSH error for '{alias}': {e}")
        except TimeoutError:
            self.log_message(f"[ERROR] Connection to '{alias}' timed out after {SSH_CONNECT_TIMEOUT}s.")
        except Exception as e:
            self.log_message(f"[FATAL] Unknown error during SSH to '{alias}': {e}")
        finally:
            if 'ssh' in locals() and ssh:
                ssh.close()

    def run_mass_action_thread(self, pc_list, action_type, command=None):
        """Launches parallel threads to run a command on a list of PCs."""

        if command is None:
            commands = {
                "reboot": "sudo -S reboot now &",
                "shutdown": "sudo -S shutdown now &",
                "update": "sudo -S sh -c 'export DEBIAN_FRONTEND=noninteractive; dpkg --configure -a; apt update; apt-get upgrade -y --fix-new-pkgs --fix-missing < /dev/null; echo \"REMOTE_UPDATE_COMPLETE\"'",
            }
            command = commands.get(action_type)

        if not command:
            self.log_message(f"[FATAL] Unknown action type '{action_type}'. Cannot run command.")
            return

        threads = []
        for pc_info in pc_list:
            thread = threading.Thread(
                target=self._run_ssh_command,
                args=(pc_info, command, action_type),
                daemon=True
            )
            threads.append(thread)
            thread.start()

        self.log_message(f"[INFO] All '{action_type}' threads initiated. See logs for progress on individual PCs.")


    # --- Add/Edit/Delete Actions ---
    def _handle_add_pc_response(self, dialog, response):
        """Processes the result of the AddPCDialog and initiates status check."""

        if response == Gtk.ResponseType.OK:
            data = dialog.get_data()
            alias = data['alias']
            hostname = data['hostname']
            username = data['username']
            password = data['password']

            if not all([alias, hostname, username, password]):
                self.log_message("[ERROR] Failed to add PC: All fields must be filled.")
            else:
                try:
                    # Encrypt the password
                    encrypted_password = self.encryption_util.encrypt(password)

                    # 1. Save to database and get the new ID
                    new_pc_id = self.db_manager.add_pc(hostname, username, encrypted_password, alias)

                    self.log_message(f"[INFO] Successfully added PC: '{alias}' ({hostname}).")
                    self.load_pc_data()

                    # 2. Find the newly added PC info
                    new_pc_info = next((p for p in self.pc_list_data if p["id"] == new_pc_id), None)

                    # 3. Auto-validate connection and check updates
                    if new_pc_info:
                        self.log_message(f"[INFO] Initiating connection and update check for new PC: '{alias}'.")
                        thread = threading.Thread(
                            target=self._check_pc_status_thread,
                            args=(new_pc_info,),
                            daemon=True
                        )
                        thread.start()

                except Exception as e:
                    self.log_message(f"[FATAL] Error adding PC: {e}")

        elif response == Gtk.ResponseType.CANCEL:
            self.log_message("[INFO] Add PC cancelled by user.")

        if GTK_VERSION == 4:
            dialog.close()
        else:
            dialog.destroy()


    def on_add_pc_clicked(self, widget):
        """Displays the 'Add PC' dialog and handles the response."""
        dialog = AddPCDialog(self)

        # Set button label for 'Add' action
        if GTK_VERSION == 4:
            dialog.add_button("_ADD", Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            dialog.connect("response", self._handle_add_pc_response)
            dialog.present()
        else:
            dialog.add_buttons(
                "_Cancel", Gtk.ResponseType.CANCEL,
                "_Add", Gtk.ResponseType.OK
            )
            dialog.set_default_response(Gtk.ResponseType.OK)
            response = dialog.run()
            self._handle_add_pc_response(dialog, response)

    # --- START OF MODIFICATION: New Edit PC Action Handlers ---
    def on_edit_pc_clicked(self, widget):
        """Displays the 'Edit PC' dialog and handles the response."""

        # We only allow single selection for editing for simplicity
        model, path_list = self.selection.get_selected_rows()
        if not path_list or len(path_list) > 1:
            self.log_message("[ERROR] Select exactly ONE PC to edit.")
            return

        selected_id = model.get_value(model.get_iter(path_list[0]), 0)

        # Get current PC data
        pc_info = next((p for p in self.pc_list_data if p["id"] == selected_id), None)
        if not pc_info:
            self.log_message(f"[ERROR] Could not find data for selected PC ID {selected_id}.")
            return

        dialog = AddPCDialog(self) # Re-use the dialog class
        dialog.set_title("Edit PC: " + pc_info['alias'])

        # Pre-fill entries
        dialog.entries["alias_entry"].set_text(pc_info["alias"])
        dialog.entries["hostname_entry"].set_text(pc_info["hostname"])
        dialog.entries["username_entry"].set_text(pc_info["username"])

        # Change button label from ADD to SAVE
        if GTK_VERSION == 4:
             # GTK4's Dialog.add_button works differently, need to re-create the main button
            pass # Keep default OK/CANCEL buttons, handle it in response
        else:
            # GTK3 has to re-add buttons to change the label
            dialog.action_area.foreach(dialog.action_area.remove)
            dialog.add_buttons(
                "_Cancel", Gtk.ResponseType.CANCEL,
                "_Save", Gtk.ResponseType.OK
            )
            dialog.set_default_response(Gtk.ResponseType.OK)

        # Store PC ID and original encrypted password on the dialog object
        dialog.pc_id = selected_id
        dialog.original_encrypted_password = pc_info["password_encrypted"]


        if GTK_VERSION == 4:
            dialog.connect("response", self._handle_edit_pc_response)
            dialog.present()
        else:
            dialog.show_all()
            response = dialog.run()
            self._handle_edit_pc_response(dialog, response)


    def _handle_edit_pc_response(self, dialog, response):
        """Processes the result of the Edit PC dialog and updates the database."""

        if response == Gtk.ResponseType.OK:
            data = dialog.get_data()
            alias = data['alias']
            hostname = data['hostname']
            username = data['username']
            password = data['password']
            pc_id = dialog.pc_id

            if not all([alias, hostname, username]):
                self.log_message("[ERROR] Failed to edit PC: Alias, Hostname, and Username must be filled.")
            else:
                try:
                    # Use new password if provided, otherwise use the original encrypted password
                    if password:
                        encrypted_password = self.encryption_util.encrypt(password)
                    else:
                        # Use the original, already encrypted password
                        encrypted_password = dialog.original_encrypted_password

                    # 1. Update the database
                    self.db_manager.update_pc(pc_id, hostname, username, encrypted_password, alias)

                    self.log_message(f"[INFO] Successfully updated PC: '{alias}' (ID: {pc_id}).")
                    self.load_pc_data()

                    # 2. Re-validate connection and check updates
                    updated_pc_info = next((p for p in self.pc_list_data if p["id"] == pc_id), None)
                    if updated_pc_info:
                         self.log_message(f"[INFO] Initiating connection and update check for updated PC: '{alias}'.")
                         thread = threading.Thread(
                             target=self._check_pc_status_thread,
                             args=(updated_pc_info,),
                             daemon=True
                         )
                         thread.start()

                except Exception as e:
                    self.log_message(f"[FATAL] Error updating PC: {e}")

        elif response == Gtk.ResponseType.CANCEL:
            self.log_message("[INFO] Edit PC cancelled by user.")

        if GTK_VERSION == 4:
            dialog.close()
        else:
            dialog.destroy()
    # --- END OF MODIFICATION: New Edit PC Action Handlers ---


    def on_refresh_clicked(self, widget):
        """Initiates a threaded status check for all registered PCs."""
        self.log_message("[INFO] Starting status check for all registered PCs...")

        self.load_pc_data()

        if not self.pc_list_data:
            self.log_message("[INFO] No PCs registered. Add a PC first.")
            return

        for pc_info in self.pc_list_data:
            if pc_info["id"] in self.monitoring_pcs:
                self.log_message(f"[INFO] Skipping status check for '{pc_info['alias']}': Currently being monitored after command.")
                continue

            thread = threading.Thread(
                target=self._check_pc_status_thread,
                args=(pc_info,),
                daemon=True
            )
            thread.start()


    def on_action_clicked(self, widget, action):
        """
        Handler for Run Update (single/multi PC action).
        If no PCs are selected, it runs the 'update' action ONLY on PCs with pending updates.
        """
        model, path_list = self.selection.get_selected_rows()
        selected_ids = [model.get_value(model.get_iter(path), 0) for path in path_list]

        if selected_ids:
            # Case 1: Specific PCs Selected (Run action on ALL selected)
            selected_pcs = [p for p in self.pc_list_data if p["id"] in selected_ids]

        elif action == "update":
            # Case 2: Update action with NO PCs selected (Run only on PCs needing update)
            # Re-load data to ensure update counts are fresh before filtering
            self.load_pc_data()
            selected_pcs = [p for p in self.pc_list_data if p["pending_updates"] > 0]

            if not selected_pcs:
                self.log_message(f"[INFO] Action '{action.upper()}' skipped: No PCs selected, and no registered PCs currently show pending updates.")
                return

        else:
            # Case 3: Other actions (Reboot, Shutdown) with NO PCs selected
            # (Require explicit selection for destructive actions)
            self.log_message(f"[ERROR] Cannot run action '{action.upper()}': No PC selected. Destructive actions require explicit selection.")
            return

        self.log_message(f"[INFO] Running {action.upper()} on {len(selected_pcs)} PC(s)...")
        self.run_mass_action_thread(selected_pcs, action)


    def on_delete_pc_clicked(self, widget, target_ids=None):
        """Handles the 'Delete PC' confirmation response."""

        if target_ids is None:
            # Fallback for unexpected call, get from current selection
            model, path_list = self.selection.get_selected_rows()
            target_ids = [model.get_value(model.get_iter(path), 0) for path in path_list]

        if not target_ids:
            self.log_message("[ERROR] Delete failed: No PC selected.")
            return

        for pc_id in target_ids:
            if pc_id in self.monitoring_pcs:
                 self.monitoring_pcs.pop(pc_id)
                 self.log_message(f"[INFO] Monitoring for PC ID {pc_id} stopped.")

            self.db_manager.delete_pc(pc_id)
            alias = next((p['alias'] for p in self.pc_list_data if p['id'] == pc_id), 'N/A')
            self.log_message(f"[INFO] PC ID {pc_id} (Alias: {alias}) deleted from database.")

        self.selected_pc_id = None
        self.load_pc_data()


    # --- Deploy Software Action Handlers ---
    def on_deploy_software_clicked(self, widget):
        """Displays the 'Deploy Software' dialog for mass installation."""

        # We allow the dialog to open even if no PCs are selected,
        # as the logic will decide to apply to ALL if selection is empty.

        dialog = DeploySoftwareDialog(self)

        if GTK_VERSION == 4:
            dialog.connect("response", self._handle_deploy_software_response)
            dialog.present()
        else:
            response = dialog.run()
            self._handle_deploy_software_response(dialog, response)

    def _handle_deploy_software_response(self, dialog, response):
        """
        Processes the result of the DeploySoftwareDialog.
        Applies to ALL PCs if none are selected, otherwise to selected PCs.
        """
        if response == Gtk.ResponseType.OK:
            packages = dialog.get_packages()

            if not packages:
                self.log_message("[ERROR] No software packages entered for deployment.")
            else:
                model, path_list = self.selection.get_selected_rows()
                selected_ids = [model.get_value(model.get_iter(path), 0) for path in path_list]

                # --- NEW LOGIC IMPLEMENTATION (Apply to ALL if none selected) ---
                if not selected_ids:
                    # Case 1: No PCs selected, deploy to ALL PCs
                    self.load_pc_data() # Ensure list is fresh
                    selected_pcs = self.pc_list_data
                    if not selected_pcs:
                        self.log_message("[ERROR] Deployment failed: No PCs are registered in the database.")
                        if GTK_VERSION == 4: dialog.close()
                        else: dialog.destroy()
                        return
                    scope = "ALL registered PCs"
                else:
                    # Case 2: Specific PCs selected, deploy to SELECTED PCs
                    selected_pcs = [p for p in self.pc_list_data if p["id"] in selected_ids]
                    scope = f"{len(selected_pcs)} selected PC(s)"
                # --- END NEW LOGIC ---

                self.log_message(f"[INFO] Deploying packages: {', '.join(packages)} to {scope}...")

                package_list = ' '.join(packages)

                # The command uses a single sudo -S wrapper for reliability.
                command = f"sudo -S sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y {package_list} < /dev/null && echo \"DEPLOYMENT_SUCCESSFUL\" || echo \"DEPLOYMENT_FAILED\"'"

                self.run_mass_action_thread(selected_pcs, "deploy", command=command)

        if GTK_VERSION == 4:
            dialog.close()
        else:
            dialog.destroy()


# --- GTK Application Wrapper ---
class RemoteLinuxManager(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=APP_FLAGS)
        self.db = DBManager()
        self.win = None

    def do_activate(self):
        # FIX: Removed self.hold() to allow the application to close when the window is closed.
        print("[DEBUG] GTK Application activated.")
        if not self.win:
            print("[DEBUG] Creating main window...")
            self.win = PCManager(self, self.db)
        try:
            display = Gdk.Display.get_default()
            if display:
                print(f"[DEBUG] Display found: {display.get_name()}")
            else:
                print("[ERROR] No display found! Must run in GUI session.")
        except Exception as e:
            print(f"[WARN] Display query failed: {e}")
        self.win.present()
        print("[DEBUG] Window presented.")


# --- Main Entry ---
if __name__ == "__main__":
    # Ensure sys.argv is checked for a GTK version hint if not already set, though this example assumes default setup

    # We explicitly print the version detected/used by the application logic
    print(f"[INFO] Running GTK {GTK_VERSION} application loop...")
    app = RemoteLinuxManager()
    code = app.run(sys.argv)
    sys.exit(code)