#!/bin/bash
#  ***** use this to launch Manager.py from Mac OS *****
#  ***** NOTE: you will be asked for a password to install dependencies from Xcode and Homebrew on first run *****
#  ***** this script should work on the latest Mac OS but will not run on older Mac OS like Monterey ******
#
# --- Configuration ---
SCRIPT_DIR="$(dirname "$0")"
VENV_PATH="$SCRIPT_DIR/.venv_manager"
PYTHON_BIN_NAME="python3"
SCRIPT_NAME="manager.py"

clear
echo "--- Remote Manager Startup for macOS ---"
echo ""

# ===============================================
# 0. ENSURE HOMEBREW ENVIRONMENT IS LOADED
# ===============================================
if command -v brew &> /dev/null; then
    echo "[INFO] Loading Homebrew environment..."
    # Attempt to load Homebrew path for both Apple Silicon (/opt) and Intel (/usr/local)
    eval "$(/opt/homebrew/bin/brew shellenv)" || eval "$(/usr/local/bin/brew shellenv)"
fi

# ===============================================
# 1. Check/Install Xcode Command Line Tools
# ===============================================
if ! command -v xcode-select &> /dev/null; then
    echo "[INFO] Xcode Command Line Tools are missing."
    echo "[ACTION] Attempting to install Xcode Command Line Tools..."
    xcode-select --install
    echo ""
    echo "[IMPORTANT] Please wait for the Apple dialog box to complete the installation."
    echo "After installation, re-run this script."
    exit 0
fi

# ===============================================
# 2. Check/Install Homebrew
# ===============================================
if ! command -v brew &> /dev/null; then
    echo "[INFO] Homebrew is missing."
    echo "[ACTION] Attempting to install Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    INSTALL_STATUS=$?
    if [ $INSTALL_STATUS -ne 0 ]; then
        echo ""
        echo "[FATAL] Homebrew installation failed. Please check network and permissions."
        exit 1
    fi
    echo "[SUCCESS] Homebrew installed."
    echo ""
    
    echo "[ACTION] Forcing shell environment update..."
    eval "$(/opt/homebrew/bin/brew shellenv)" || eval "$(/usr/local/bin/brew shellenv)"
fi

# ===============================================
# 3. CRITICAL: Install Dependencies (Tcl/Tk, libffi, and Python 3)
# ===============================================

# 3a. Install modern Tcl/Tk (Fixes Abort trap: 6 on GUI launch)
if ! brew list tcl-tk &> /dev/null; then
    echo "[ACTION] Installing stable Tcl/Tk for Tkinter compatibility..."
    brew install tcl-tk
fi

# 3b. Install libffi and OpenSSL 3 (Fixes compilation errors like bcrypt/cryptography)
if ! brew list libffi &> /dev/null || ! brew list openssl@3 &> /dev/null; then
    echo "[ACTION] Installing libffi and OpenSSL 3 (required for cryptography compilation)..."
    brew install libffi openssl@3 
fi

# 3c. Install Python 3
PYTHON_BIN_PATH=$(command -v $PYTHON_BIN_NAME)

if [ -z "$PYTHON_BIN_PATH" ]; then
    echo "[INFO] Python 3 (via Homebrew) is missing."
    echo "[ACTION] Installing Python 3 via Homebrew..."
    brew install python 
    if [ $? -ne 0 ]; then
        echo "[FATAL] Failed to install Python via Homebrew. Exiting."
        exit 1
    fi
    echo "[SUCCESS] Python 3 installed. Re-checking path..."
    PYTHON_BIN_PATH=$(command -v $PYTHON_BIN_NAME)
fi

# ===============================================
# 4. Virtual Environment Setup and Dependency Installation
# ===============================================

# 4a. Virtual Environment Setup
if [ ! -d "$VENV_PATH" ]; then
    echo "[INFO] Setting up new Python Virtual Environment using: $PYTHON_BIN_PATH"
    "$PYTHON_BIN_PATH" -m venv "$VENV_PATH"
fi

# 4b. Define Venv Binaries
VENV_PYTHON="$VENV_PATH/bin/python"
VENV_PIP="$VENV_PATH/bin/pip"

# 4c. Install Python Dependencies
echo "[INFO] Checking and installing Python dependencies: paramiko, cryptography..."

# --- CRITICAL FIX: EXPORT COMPILER FLAGS USING HOMEBREW'S DYNAMIC PATHS ---
# This is reliable on modern macOS
OPENSSL_PREFIX=$(brew --prefix openssl@3)
LIBFFI_PREFIX=$(brew --prefix libffi)

export LDFLAGS="-L$OPENSSL_PREFIX/lib -L$LIBFFI_PREFIX/lib"
export CPPFLAGS="-I$OPENSSL_PREFIX/include -I$LIBFFI_PREFIX/include"
echo "[INFO] Dynamic LDFLAGS/CPPFLAGS set for compiler linking."


# Create a temporary requirements file for pip
cat <<EOF > "$SCRIPT_DIR/temp_requirements.txt"
paramiko
cryptography
EOF

# --- CRITICAL FIX: --no-binary :all: (Forces successful linking) ---
"$VENV_PIP" install -r "$SCRIPT_DIR/temp_requirements.txt" --disable-pip-version-check --no-binary :all:
INSTALL_STATUS=$?

# Clean up environment variables and temp file
unset OPENSSL_PREFIX
unset LIBFFI_PREFIX
unset LDFLAGS
unset CPPFLAGS
rm "$SCRIPT_DIR/temp_requirements.txt"

if [ $INSTALL_STATUS -ne 0 ]; then
    echo "[ERROR] Failed to install Python dependencies! The compiler could not build them."
    echo "If this occurs on a modern macOS, try installing dependencies directly without --no-binary :all:."
    exit 1
fi

# ===============================================
# 5. Launch Application
# ===============================================
echo "[INFO] Dependencies met. Launching $SCRIPT_NAME..."
"$VENV_PYTHON" "$SCRIPT_DIR/$SCRIPT_NAME"

# ===============================================
# 6. Exit
# ===============================================
echo ""
echo "Script finished."
exit 0
